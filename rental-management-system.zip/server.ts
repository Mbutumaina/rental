import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;
const DATA_FILE = path.join(process.cwd(), "data_store.json");

app.use(express.json());

// Initialize Gemini safely
let ai: GoogleGenAI | null = null;
try {
  const apiKey = process.env.GEMINI_API_KEY;
  if (apiKey) {
    ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  } else {
    console.warn("GEMINI_API_KEY helper is missing. AI features will fallback to helpful simulation templates.");
  }
} catch (err) {
  console.error("Failed to initialize Gemini:", err);
}

// ----------------------------------------------------
// Core Data Persistence with high quality Seed Data
// ----------------------------------------------------
interface StoreData {
  properties: any[];
  tenants: any[];
  leases: any[];
  payments: any[];
  maintenance: any[];
}

const DEFAULT_DATA: StoreData = {
  properties: [
    {
      id: "prop-1",
      name: "Cedar Meadow Townhouse #4",
      address: "839 Whitetail Lane, Austin, TX 78745",
      type: "House",
      rentAmount: 2400,
      status: "Occupied",
      bedrooms: 3,
      bathrooms: 2.5,
      imageUrl: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=800&q=80",
      description: "Charming suburban townhouse with attached two-car garage, private backyard deck, and open floor kitchen. Located in a top-rated school district.",
      createdAt: new Date(Date.now() - 360 * 24 * 3600 * 1000).toISOString()
    },
    {
      id: "prop-2",
      name: "The Luminary Penthouse A",
      address: "100 Pine Street, San Francisco, CA 94111",
      type: "Apartment",
      rentAmount: 4800,
      status: "Occupied",
      bedrooms: 2,
      bathrooms: 2,
      imageUrl: "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&w=800&q=80",
      description: "Sky-high panoramic luxury penthouse inside a premium high-rise. Features imported marble, custom smart-home configurations, floor-to-ceiling glass, and access to a rooftop pool.",
      createdAt: new Date(Date.now() - 180 * 24 * 3600 * 1000).toISOString()
    },
    {
      id: "prop-3",
      name: "Pacific Heights Studio Loft",
      address: "1240 Broadway Blvd #310, Oakland, CA 94612",
      type: "Studio",
      rentAmount: 1850,
      status: "Vacant",
      bedrooms: 1,
      bathrooms: 1,
      imageUrl: "https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?auto=format&fit=crop&w=800&q=80",
      description: "Industrial loft with high exposed concrete ceilings, large historic steel windows, and original hardwood flooring. Walkable to rapid transport links, cafes, and parks.",
      createdAt: new Date(Date.now() - 90 * 24 * 3600 * 1000).toISOString()
    },
    {
      id: "prop-4",
      name: "Mission District Live-Work Studio",
      address: "479 Guerrero Street, San Francisco, CA 94110",
      type: "Studio",
      rentAmount: 2200,
      status: "Maintenance",
      bedrooms: 1,
      bathrooms: 1,
      imageUrl: "https://images.unsplash.com/photo-1493809842364-78817add7ffb?auto=format&fit=crop&w=800&q=80",
      description: "Spacious studio suitable for dual live and work setup. Concrete floors, dynamic track lights, and updated dishwasher. Undergoing fresh painting.",
      createdAt: new Date(Date.now() - 45 * 24 * 3600 * 1000).toISOString()
    }
  ],
  tenants: [
    {
      id: "tenant-1",
      name: "Elena Rostova",
      email: "elena.r@example.com",
      phone: "(512) 555-0149",
      status: "Active",
      propertyId: "prop-1",
      createdAt: new Date(Date.now() - 250 * 24 * 3600 * 1000).toISOString()
    },
    {
      id: "tenant-2",
      name: "Marcus Vance",
      email: "marcus.vance@example.com",
      phone: "(415) 332-9840",
      status: "Active",
      propertyId: "prop-2",
      createdAt: new Date(Date.now() - 170 * 24 * 3600 * 1000).toISOString()
    },
    {
      id: "tenant-3",
      name: "Samantha Lopez",
      email: "sam.lopez@example.com",
      phone: "(510) 901-2244",
      status: "Applicant",
      createdAt: new Date(Date.now() - 12 * 24 * 3600 * 1000).toISOString()
    }
  ],
  leases: [
    {
      id: "lease-1",
      propertyId: "prop-1",
      tenantId: "tenant-1",
      startDate: "2025-08-01",
      endDate: "2026-07-31",
      rentAmount: 2400,
      depositAmount: 2400,
      status: "Active",
      terms: "1. Rent is due on the 1st of each month. A late fee of $75 applies after the 5th.\n2. Subletting is explicitly prohibited without landlord written authorization.\n3. Tenants are responsible for keeping the fenced yard neat and functional.\n4. No smoking inside the premises.",
      createdAt: new Date(Date.now() - 250 * 24 * 3600 * 1000).toISOString()
    },
    {
      id: "lease-2",
      propertyId: "prop-2",
      tenantId: "tenant-2",
      startDate: "2025-10-15",
      endDate: "2026-10-14",
      rentAmount: 4800,
      depositAmount: 5000,
      status: "Active",
      terms: "1. Rent payable electronically. Due on the 15th of each month.\n2. The property includes 2 parking spaces in the basement garage.\n3. Small domestic pets are allowed with a $500 designated pet deposit.\n4. Standard pool and amenity rules must be carefully maintained.",
      createdAt: new Date(Date.now() - 170 * 24 * 3600 * 1000).toISOString()
    }
  ],
  payments: [
    {
      id: "pay-1",
      leaseId: "lease-1",
      tenantId: "tenant-1",
      propertyId: "prop-1",
      amount: 2400,
      date: "2026-06-01",
      status: "Paid",
      type: "Rent",
      notes: "June 2026 Rent Payment - Received electronically transfer"
    },
    {
      id: "pay-2",
      leaseId: "lease-1",
      tenantId: "tenant-1",
      propertyId: "prop-1",
      amount: 2400,
      date: "2026-05-01",
      status: "Paid",
      type: "Rent",
      notes: "May Rent"
    },
    {
      id: "pay-3",
      leaseId: "lease-1",
      tenantId: "tenant-1",
      propertyId: "prop-1",
      amount: 2400,
      date: "2026-04-01",
      status: "Paid",
      type: "Rent",
      notes: ""
    },
    {
      id: "pay-4",
      leaseId: "lease-2",
      tenantId: "tenant-2",
      propertyId: "prop-2",
      amount: 4800,
      date: "2026-05-15",
      status: "Paid",
      type: "Rent",
      notes: "May Mid-month Rent"
    },
    {
      id: "pay-5",
      leaseId: "lease-2",
      tenantId: "tenant-2",
      propertyId: "prop-2",
      amount: 4800,
      date: "2026-06-15",
      status: "Pending",
      type: "Rent",
      notes: "Upcoming Rent Payment Statement"
    }
  ],
  maintenance: [
    {
      id: "maint-1",
      propertyId: "prop-1",
      tenantId: "tenant-1",
      title: "Garbage Disposal Jammed",
      description: "Kitchen sink is clogged up, the motor makes a buzzing hum but the blades are locked. Need a plumber or handyman to inspect.",
      priority: "Medium",
      status: "In Progress",
      dateReported: "2026-06-11T14:30:22.000Z"
    },
    {
      id: "maint-2",
      propertyId: "prop-2",
      tenantId: "tenant-2",
      title: "HVAC thermostat display dead",
      description: "Air conditioner cool is technically working but the smart screen display on the nest is completely blank and won't charge or wake up.",
      priority: "Low",
      status: "New",
      dateReported: "2026-06-13T09:15:00.000Z"
    },
    {
      id: "maint-3",
      propertyId: "prop-1",
      tenantId: "tenant-1",
      title: "Back porch door latch replaced",
      description: "Lock mechanism worn down and wouldn't snap shut in wind.",
      priority: "Low",
      status: "Resolved",
      dateReported: "2026-05-02T10:00:00.000Z",
      dateResolved: "2026-05-04T16:45:00.000Z"
    }
  ]
};

// Help load/save state
function loadStore(): StoreData {
  try {
    if (fs.existsSync(DATA_FILE)) {
      const parsed = JSON.parse(fs.readFileSync(DATA_FILE, "utf-8"));
      // Ensure basic keys are always populated
      return {
        properties: parsed.properties || [],
        tenants: parsed.tenants || [],
        leases: parsed.leases || [],
        payments: parsed.payments || [],
        maintenance: parsed.maintenance || [],
      };
    }
  } catch (err) {
    console.error("Could not parse data file, falling back to default data", err);
  }
  
  // Seed file with default data if empty or missing
  saveStore(DEFAULT_DATA);
  return DEFAULT_DATA;
}

function saveStore(data: StoreData) {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), "utf-8");
  } catch (err) {
    console.error("Failed to save data file:", err);
  }
}

// ----------------------------------------------------
// REST Endpoints
// ----------------------------------------------------

// GET PROPERTIES
app.get("/api/properties", (req, res) => {
  const data = loadStore();
  res.json(data.properties);
});

// CREATE PROPERTY
app.post("/api/properties", (req, res) => {
  const data = loadStore();
  const newProp = {
    id: `prop-${Date.now()}`,
    name: req.body.name,
    address: req.body.address,
    type: req.body.type || "Apartment",
    rentAmount: Number(req.body.rentAmount) || 1200,
    status: req.body.status || "Vacant",
    bedrooms: Number(req.body.bedrooms) || 1,
    bathrooms: Number(req.body.bathrooms) || 1,
    imageUrl: req.body.imageUrl || "https://images.unsplash.com/photo-1564013799919-ab600027ffc6?auto=format&fit=crop&w=800&q=80",
    description: req.body.description || "",
    createdAt: new Date().toISOString()
  };
  data.properties.push(newProp);
  saveStore(data);
  res.status(201).json(newProp);
});

// UPDATE PROPERTY
app.put("/api/properties/:id", (req, res) => {
  const data = loadStore();
  const index = data.properties.findIndex(p => p.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ error: "Property not found" });
  }
  
  data.properties[index] = {
    ...data.properties[index],
    name: req.body.name !== undefined ? req.body.name : data.properties[index].name,
    address: req.body.address !== undefined ? req.body.address : data.properties[index].address,
    type: req.body.type !== undefined ? req.body.type : data.properties[index].type,
    rentAmount: req.body.rentAmount !== undefined ? Number(req.body.rentAmount) : data.properties[index].rentAmount,
    status: req.body.status !== undefined ? req.body.status : data.properties[index].status,
    bedrooms: req.body.bedrooms !== undefined ? Number(req.body.bedrooms) : data.properties[index].bedrooms,
    bathrooms: req.body.bathrooms !== undefined ? Number(req.body.bathrooms) : data.properties[index].bathrooms,
    imageUrl: req.body.imageUrl !== undefined ? req.body.imageUrl : data.properties[index].imageUrl,
    description: req.body.description !== undefined ? req.body.description : data.properties[index].description,
  };
  saveStore(data);
  res.json(data.properties[index]);
});

// DELETE PROPERTY
app.delete("/api/properties/:id", (req, res) => {
  const data = loadStore();
  data.properties = data.properties.filter(p => p.id !== req.params.id);
  // Also clean up or flag orphan records if needed (we keep it simple here)
  saveStore(data);
  res.json({ success: true, id: req.params.id });
});

// GET TENANTS
app.get("/api/tenants", (req, res) => {
  const data = loadStore();
  res.json(data.tenants);
});

// CREATE TENANT
app.post("/api/tenants", (req, res) => {
  const data = loadStore();
  const newTenant = {
    id: `tenant-${Date.now()}`,
    name: req.body.name,
    email: req.body.email,
    phone: req.body.phone,
    status: req.body.status || "Applicant",
    propertyId: req.body.propertyId || null,
    createdAt: new Date().toISOString()
  };
  // If propertyId assigned, update property status to occupied
  if (newTenant.propertyId) {
    const propIndex = data.properties.findIndex(p => p.id === newTenant.propertyId);
    if (propIndex !== -1) {
      data.properties[propIndex].status = "Occupied";
    }
  }
  data.tenants.push(newTenant);
  saveStore(data);
  res.status(201).json(newTenant);
});

// UPDATE TENANT
app.put("/api/tenants/:id", (req, res) => {
  const data = loadStore();
  const index = data.tenants.findIndex(t => t.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ error: "Tenant not found" });
  }
  
  const oldPropertyId = data.tenants[index].propertyId;
  const newPropertyId = req.body.propertyId;
  
  data.tenants[index] = {
    ...data.tenants[index],
    name: req.body.name !== undefined ? req.body.name : data.tenants[index].name,
    email: req.body.email !== undefined ? req.body.email : data.tenants[index].email,
    phone: req.body.phone !== undefined ? req.body.phone : data.tenants[index].phone,
    status: req.body.status !== undefined ? req.body.status : data.tenants[index].status,
    propertyId: req.body.propertyId !== undefined ? req.body.propertyId : data.tenants[index].propertyId,
  };
  
  // If property assignments changed, update property status
  if (req.body.propertyId !== undefined && oldPropertyId !== newPropertyId) {
    if (oldPropertyId) {
      const oldPropIdx = data.properties.findIndex(p => p.id === oldPropertyId);
      if (oldPropIdx !== -1) {
        // Mark vacant if no other active tenant is linked
        const stillActive = data.tenants.some(t => t.id !== req.params.id && t.propertyId === oldPropertyId && t.status === "Active");
        if (!stillActive) {
          data.properties[oldPropIdx].status = "Vacant";
        }
      }
    }
    if (newPropertyId) {
      const newPropIdx = data.properties.findIndex(p => p.id === newPropertyId);
      if (newPropIdx !== -1) {
        data.properties[newPropIdx].status = "Occupied";
      }
    }
  }
  
  saveStore(data);
  res.json(data.tenants[index]);
});

// DELETE TENANT
app.delete("/api/tenants/:id", (req, res) => {
  const data = loadStore();
  const tenant = data.tenants.find(t => t.id === req.params.id);
  if (tenant && tenant.propertyId) {
    const propIdx = data.properties.findIndex(p => p.id === tenant.propertyId);
    if (propIdx !== -1) {
      data.properties[propIdx].status = "Vacant";
    }
  }
  data.tenants = data.tenants.filter(t => t.id !== req.params.id);
  saveStore(data);
  res.json({ success: true, id: req.params.id });
});

// GET LEASES
app.get("/api/leases", (req, res) => {
  const data = loadStore();
  res.json(data.leases);
});

// CREATE LEASE
app.post("/api/leases", (req, res) => {
  const data = loadStore();
  const newLease = {
    id: `lease-${Date.now()}`,
    propertyId: req.body.propertyId,
    tenantId: req.body.tenantId,
    startDate: req.body.startDate,
    endDate: req.body.endDate,
    rentAmount: Number(req.body.rentAmount) || 1200,
    depositAmount: Number(req.body.depositAmount) || 1200,
    status: req.body.status || "Active",
    terms: req.body.terms || "Standard Residential Lease Terms...",
    createdAt: new Date().toISOString()
  };
  
  // Link automatically
  const tenantIdx = data.tenants.findIndex(t => t.id === newLease.tenantId);
  if (tenantIdx !== -1) {
    data.tenants[tenantIdx].propertyId = newLease.propertyId;
    data.tenants[tenantIdx].status = "Active";
  }
  const propIdx = data.properties.findIndex(p => p.id === newLease.propertyId);
  if (propIdx !== -1) {
    data.properties[propIdx].status = "Occupied";
  }
  
  data.leases.push(newLease);
  saveStore(data);
  res.status(201).json(newLease);
});

// UPDATE LEASE
app.put("/api/leases/:id", (req, res) => {
  const data = loadStore();
  const index = data.leases.findIndex(l => l.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ error: "Lease not found" });
  }
  
  data.leases[index] = {
    ...data.leases[index],
    startDate: req.body.startDate !== undefined ? req.body.startDate : data.leases[index].startDate,
    endDate: req.body.endDate !== undefined ? req.body.endDate : data.leases[index].endDate,
    rentAmount: req.body.rentAmount !== undefined ? Number(req.body.rentAmount) : data.leases[index].rentAmount,
    depositAmount: req.body.depositAmount !== undefined ? Number(req.body.depositAmount) : data.leases[index].depositAmount,
    status: req.body.status !== undefined ? req.body.status : data.leases[index].status,
    terms: req.body.terms !== undefined ? req.body.terms : data.leases[index].terms,
  };
  saveStore(data);
  res.json(data.leases[index]);
});

// DELETE LEASE
app.delete("/api/leases/:id", (req, res) => {
  const data = loadStore();
  data.leases = data.leases.filter(l => l.id !== req.params.id);
  saveStore(data);
  res.json({ success: true, id: req.params.id });
});

// GET PAYMENTS
app.get("/api/payments", (req, res) => {
  const data = loadStore();
  res.json(data.payments);
});

// CREATE PAYMENT
app.post("/api/payments", (req, res) => {
  const data = loadStore();
  const newPay = {
    id: `pay-${Date.now()}`,
    leaseId: req.body.leaseId || "",
    tenantId: req.body.tenantId || "",
    propertyId: req.body.propertyId || "",
    amount: Number(req.body.amount) || 0,
    date: req.body.date || new Date().toISOString().split("T")[0],
    status: req.body.status || "Paid",
    type: req.body.type || "Rent",
    notes: req.body.notes || ""
  };
  data.payments.push(newPay);
  saveStore(data);
  res.status(201).json(newPay);
});

// UPDATE PAYMENT
app.put("/api/payments/:id", (req, res) => {
  const data = loadStore();
  const index = data.payments.findIndex(p => p.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ error: "Payment not found" });
  }
  data.payments[index] = {
    ...data.payments[index],
    status: req.body.status || data.payments[index].status,
    notes: req.body.notes !== undefined ? req.body.notes : data.payments[index].notes,
    amount: req.body.amount !== undefined ? Number(req.body.amount) : data.payments[index].amount,
    date: req.body.date || data.payments[index].date
  };
  saveStore(data);
  res.json(data.payments[index]);
});

// GET MAINTENANCE REQUESTS
app.get("/api/maintenance", (req, res) => {
  const data = loadStore();
  res.json(data.maintenance);
});

// CREATE MAINTENANCE REQUEST
app.post("/api/maintenance", (req, res) => {
  const data = loadStore();
  const newMaint = {
    id: `maint-${Date.now()}`,
    propertyId: req.body.propertyId || "",
    tenantId: req.body.tenantId || "",
    title: req.body.title,
    description: req.body.description,
    priority: req.body.priority || "Medium",
    status: req.body.status || "New",
    dateReported: new Date().toISOString(),
    dateResolved: null
  };
  data.maintenance.push(newMaint);
  saveStore(data);
  res.status(201).json(newMaint);
});

// UPDATE MAINTENANCE REQUEST
app.put("/api/maintenance/:id", (req, res) => {
  const data = loadStore();
  const index = data.maintenance.findIndex(m => m.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ error: "Maintenance request not found" });
  }
  
  const oldStatus = data.maintenance[index].status;
  const newStatus = req.body.status;
  let dateResolved = data.maintenance[index].dateResolved;
  if (newStatus === "Resolved" && oldStatus !== "Resolved") {
    dateResolved = new Date().toISOString();
  } else if (newStatus !== "Resolved") {
    dateResolved = null;
  }
  
  data.maintenance[index] = {
    ...data.maintenance[index],
    title: req.body.title !== undefined ? req.body.title : data.maintenance[index].title,
    description: req.body.description !== undefined ? req.body.description : data.maintenance[index].description,
    priority: req.body.priority !== undefined ? req.body.priority : data.maintenance[index].priority,
    status: req.body.status !== undefined ? req.body.status : data.maintenance[index].status,
    dateResolved,
  };
  saveStore(data);
  res.json(data.maintenance[index]);
});


// ----------------------------------------------------
// AI ASSISTANT PROXY (GEMINI)
// ----------------------------------------------------
app.post("/api/assistant", async (req, res) => {
  const { messages, contextType, contextData } = req.body;
  if (!messages || !Array.isArray(messages)) {
    return res.status(400).json({ error: "Messages array is required." });
  }

  // Build context for Gemini to give expert answers about this rental
  const rentalData = loadStore();
  
  let databaseContext = "You are the Rental Intelligence AI, a world-class system embedded inside a real-time Landlord Portal & Tenant Relations console.";
  databaseContext += "\n\nCurrent system statistics and data state:";
  databaseContext += `\n- Properties (${rentalData.properties.length}): ${JSON.stringify(rentalData.properties.map(p => ({ id: p.id, name: p.name, address: p.address, status: p.status, rentAmount: p.rentAmount })))}`;
  databaseContext += `\n- Active Tenants (${rentalData.tenants.length}): ${JSON.stringify(rentalData.tenants.map(t => ({ id: t.id, name: t.name, email: t.email, propertyId: t.propertyId, status: t.status })))}`;
  databaseContext += `\n- Leases: ${JSON.stringify(rentalData.leases.map(l => ({ id: l.id, propertyId: l.propertyId, tenantId: l.tenantId, rentAmount: l.rentAmount, depositAmount: l.depositAmount, endDate: l.endDate, status: l.status })))}`;
  databaseContext += `\n- Maintenance requests outstanding: ${JSON.stringify(rentalData.maintenance.filter(m => m.status !== "Resolved").map(m => ({ id: m.id, propertyId: m.propertyId, title: m.title, priority: m.priority, status: m.status })))}`;

  if (contextType && contextData) {
    databaseContext += `\n\nSpecific entity context focused on selection:\nType: ${contextType}\nData Selected: ${JSON.stringify(contextData)}`;
  }

  const promptInput = messages[messages.length - 1].text;
  
  // Format history for Gemini chat if a thread is present
  const historyPrompt = messages.slice(0, -1).map((m: any) => `${m.role === "user" ? "User" : "Assistant"}: ${m.text}`).join("\n");

  const fullPrompt = `
System Instruction:
${databaseContext}
You specialize in property management. Treat the user as a professional property owner or tenant representative. 
Provide clear, expert answers. If asked to write emails, templates, rent reminders, or notifications, format them as copyable templates with clear subjects and salutations. Keep responses neat, highly accurate, and directly grounded in the active properties/tenant records.

Active Conversation History:
${historyPrompt}

Latest User Request:
${promptInput}

Response:
`;

  if (ai) {
    try {
      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: fullPrompt,
      });
      return res.json({ text: response.text || "I processed your request but didn't receive any text output." });
    } catch (err: any) {
      console.error("Gemini model execution failed:", err);
      return res.status(500).json({ error: `Gemini execution failed: ${err.message || String(err)}` });
    }
  } else {
    // Elegant simulated fallback answer grounding in data if no key is present.
    let responseText = "Greetings. I am operating in simulation mode as the server does not have active Gemini Credentials.\n\n";
    if (promptInput.toLowerCase().includes("reminder") || promptInput.toLowerCase().includes("email")) {
      responseText += `**Rent Reminder Draft**
      
Subject: Friendly Rent Reminder: [Property Name]
Dear [Tenant Name],

This is a polite reminder that rent of $[Amount] is due. Please submit your payment at your earliest convenience via the tenant portal.

Warm regards,
Property Management Support`;
    } else {
      responseText += `Based on our system database:
- We have ${rentalData.properties.length} properties under management with ${rentalData.properties.filter(p => p.status === "Occupied").length} currently occupied.
- There are ${rentalData.maintenance.filter(m => m.status !== 'Resolved').length} active, unresolved maintenance tickets.
Let me know if you would like automated rent reminder drafts or ticket updates, or if you configure your GEMINI_API_KEY inside the Secrets panel.`;
    }
    
    return res.json({ text: responseText });
  }
});


// ----------------------------------------------------
// VITE DEV SERVER / STATIC ASSETS PIPELINE
// ----------------------------------------------------
async function startServer() {
  // Ensure default file exists on startup
  loadStore();

  if (process.env.NODE_ENV !== "production") {
    console.log("Starting Express backend + Vite Server integration...");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    console.log("Serving build index in production mode...");
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Rental Management Server listening on port ${PORT}`);
  });
}

startServer();
