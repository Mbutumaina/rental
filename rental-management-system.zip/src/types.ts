export interface Property {
  id: string;
  name: string;
  address: string;
  type: "Apartment" | "House" | "Studio" | "Commercial";
  rentAmount: number;
  status: "Occupied" | "Vacant" | "Maintenance";
  bedrooms: number;
  bathrooms: number;
  imageUrl: string;
  description?: string;
  createdAt: string;
}

export interface Tenant {
  id: string;
  name: string;
  email: string;
  phone: string;
  status: "Active" | "Past" | "Applicant";
  propertyId?: string; // Currently renting propertyId
  createdAt: string;
}

export interface Lease {
  id: string;
  propertyId: string;
  tenantId: string;
  startDate: string;
  endDate: string;
  rentAmount: number;
  depositAmount: number;
  status: "Active" | "Pending" | "Expired" | "Terminated";
  terms: string;
  createdAt: string;
}

export interface Payment {
  id: string;
  leaseId: string;
  tenantId: string;
  propertyId: string;
  amount: number;
  date: string;
  status: "Paid" | "Pending" | "Overdue";
  type: "Rent" | "Deposit" | "Late Fee" | "Utility";
  notes?: string;
}

export interface MaintenanceRequest {
  id: string;
  propertyId: string;
  tenantId: string;
  title: string;
  description: string;
  priority: "Low" | "Medium" | "High" | "Emergency";
  status: "New" | "In Progress" | "Resolved" | "Cancelled";
  dateReported: string;
  dateResolved?: string;
}

export interface DashboardStats {
  totalRevenue: number;
  occupancyRate: number;
  activeLeases: number;
  openMaintenance: number;
}

export interface Message {
  role: "user" | "model";
  text: string;
  timestamp: string;
}
