import React, { useState } from "react";
import { 
  Wrench, 
  Plus, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  ChevronRight, 
  Building2, 
  UserCircle,
  X,
  Play,
  Check,
  AlertTriangle
} from "lucide-react";
import { MaintenanceRequest, Tenant, Property } from "../types";

interface MaintenanceProps {
  maintenance: MaintenanceRequest[];
  tenants: Tenant[];
  properties: Property[];
  onAddMaintenance: (request: Omit<MaintenanceRequest, "id" | "dateReported" | "dateResolved">) => Promise<void>;
  onUpdateMaintenance: (id: string, request: Partial<MaintenanceRequest>) => Promise<void>;
  onSelectTab: (tab: string, contextType?: string, contextData?: any) => void;
}

export default function Maintenance({ 
  maintenance, 
  tenants, 
  properties, 
  onAddMaintenance,
  onUpdateMaintenance,
  onSelectTab
}: MaintenanceProps) {

  const [isFormOpen, setIsFormOpen] = useState(false);
  const [filterPriority, setFilterPriority] = useState<"All" | "Low" | "Medium" | "High" | "Emergency">("All");
  const [filterStatus, setFilterStatus] = useState<"All" | "New" | "In Progress" | "Resolved">("All");

  // Form fields
  const [selectedPropertyId, setSelectedPropertyId] = useState("");
  const [selectedTenantId, setSelectedTenantId] = useState("");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [priority, setPriority] = useState<"Low" | "Medium" | "High" | "Emergency">("Medium");

  const [loading, setLoading] = useState(false);

  // ID mappings
  const propertyMap = React.useMemo(() => new Map(properties.map(p => [p.id, p])), [properties]);
  const tenantMap = React.useMemo(() => new Map(tenants.map(t => [t.id, t])), [tenants]);

  const handlePropertyChange = (propertyId: string) => {
    setSelectedPropertyId(propertyId);
    
    // Auto-link active tenant for that property if any
    const associatedTenant = tenants.find(t => t.propertyId === propertyId && t.status === "Active");
    if (associatedTenant) {
      setSelectedTenantId(associatedTenant.id);
    } else {
      setSelectedTenantId("");
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPropertyId || !title || !description) {
      alert("Property, title, and description are required.");
      return;
    }

    setLoading(true);
    const payload = {
      propertyId: selectedPropertyId,
      tenantId: selectedTenantId || "no-tenant",
      title,
      description,
      priority,
      status: "New" as const
    };

    try {
      await onAddMaintenance(payload);
      setIsFormOpen(false);
      // reset form
      setTitle("");
      setDescription("");
    } catch (err) {
      console.error(err);
      alert("Failed to submit maintenance claim ticket.");
    } finally {
      setLoading(false);
    }
  };

  const handleStatusChange = async (id: string, nextStatus: "New" | "In Progress" | "Resolved") => {
    try {
      await onUpdateMaintenance(id, { status: nextStatus });
    } catch (err) {
      console.error(err);
    }
  };

  const handlePriorityChange = async (id: string, nextPriority: "Low" | "Medium" | "High" | "Emergency") => {
    try {
      await onUpdateMaintenance(id, { priority: nextPriority });
    } catch (err) {
      console.error(err);
    }
  };

  const filteredRequests = maintenance.filter(m => {
    const pMatch = filterPriority === "All" || m.priority === filterPriority;
    const sMatch = filterStatus === "All" || m.status === filterStatus;
    return pMatch && sMatch;
  });

  return (
    <div className="space-y-6 animate-fadeIn" id="maintenance-view">
      
      {/* Header section */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight flex items-center">
            <Wrench className="mr-2.5 text-indigo-600" size={24} />
            Maintenance Service Desk
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Dispatch trade dispatch and track resolution. 
          </p>
        </div>

        <button 
          onClick={() => setIsFormOpen(true)}
          className="bg-indigo-600 hover:bg-indigo-700 text-white font-medium text-sm px-4.5 py-2.5 rounded-xl inline-flex items-center shadow-xs transition-colors self-start sm:self-auto"
        >
          <Plus size={16} className="mr-1.5" />
          Log Maintenance Request
        </button>
      </div>

      {/* Filter system */}
      <div className="flex flex-wrap gap-4 bg-white p-4.5 border border-slate-200 rounded-xl items-center justify-between" id="maint-filters">
        <div className="flex flex-wrap gap-4 items-center">
          <div className="flex items-center space-x-1">
            <span className="text-xs text-slate-400">Severity:</span>
            <select 
              value={filterPriority} 
              onChange={(e) => setFilterPriority(e.target.value as any)}
              className="text-xs bg-slate-50 hover:bg-slate-105 border border-slate-200 text-slate-700 px-2.5 py-1 rounded-md outline-hidden font-medium"
            >
              <option value="All">All Levels</option>
              <option value="Low">Low</option>
              <option value="Medium">Medium</option>
              <option value="High">High</option>
              <option value="Emergency">Emergency</option>
            </select>
          </div>

          <div className="flex items-center space-x-1">
            <span className="text-xs text-slate-400">Dispatch Status:</span>
            <select 
              value={filterStatus} 
              onChange={(e) => setFilterStatus(e.target.value as any)}
              className="text-xs bg-slate-50 hover:bg-slate-105 border border-slate-200 text-slate-700 px-2.5 py-1 rounded-md outline-hidden font-medium"
            >
              <option value="All">All Jobs</option>
              <option value="New">New</option>
              <option value="In Progress">In Progress</option>
              <option value="Resolved">Resolved</option>
            </select>
          </div>
        </div>

        <div className="text-xs text-slate-500 font-semibold">
          {filteredRequests.length} ticket(s) found
        </div>
      </div>

      {/* Tickets List */}
      <div className="space-y-4" id="tickets-list">
        {filteredRequests.length === 0 ? (
          <div className="bg-white border border-slate-200 rounded-2xl p-12 text-center text-slate-500">
            <Wrench className="mx-auto text-slate-300 mb-3" size={32} />
            <h3 className="font-semibold text-slate-800 mb-1">No ticket matches</h3>
            <p className="text-xs text-slate-400">All properties appear to be operating smoothly!</p>
          </div>
        ) : (
          filteredRequests.map(m => {
            const property = propertyMap.get(m.propertyId);
            const tenant = tenantMap.get(m.tenantId);
            
            return (
              <div 
                key={m.id}
                className="bg-white border border-slate-200 rounded-xl p-5 hover:border-slate-300 transition-colors shadow-xxs flex flex-col md:flex-row md:items-center justify-between gap-5"
              >
                {/* Details left side */}
                <div className="space-y-3.5 flex-1 max-w-xl">
                  <div className="flex flex-wrap items-center gap-2">
                    {/* Severity color-coded pill */}
                    <select
                      value={m.priority}
                      onChange={(e) => handlePriorityChange(m.id, e.target.value as any)}
                      className={`text-xxs font-bold tracking-wider uppercase px-2 py-0.5 rounded cursor-pointer ${
                        m.priority === "Emergency" ? "bg-red-100 text-red-850" :
                        m.priority === "High" ? "bg-amber-100 text-amber-850" :
                        m.priority === "Medium" ? "bg-indigo-100 text-indigo-850" :
                        "bg-slate-100 text-slate-700"
                      }`}
                      title="Update Priority Severity"
                    >
                      <option value="Low">Low</option>
                      <option value="Medium">Medium</option>
                      <option value="High">High</option>
                      <option value="Emergency">Emergency</option>
                    </select>

                    {/* Status Pill */}
                    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xxs font-semibold ${
                      m.status === "Resolved" ? "bg-emerald-50 text-emerald-700 border border-emerald-100" :
                      m.status === "In Progress" ? "bg-amber-50 text-amber-700 border border-amber-100 animate-pulse" :
                      "bg-rose-50 text-rose-700 border border-rose-100"
                    }`}>
                      {m.status}
                    </span>

                    <span className="text-xxs text-slate-400">
                      Reported {new Date(m.dateReported).toLocaleDateString()}
                    </span>
                  </div>

                  <div>
                    <h3 className="font-semibold text-slate-900 text-base">{m.title}</h3>
                    <p className="text-xs text-slate-600 mt-1 leading-relaxed">{m.description}</p>
                  </div>

                  {/* Property connection detail */}
                  <div className="flex flex-wrap gap-4 text-xxs text-slate-500 font-medium pt-1">
                    <div className="flex items-center space-x-1.5 bg-slate-50 border border-slate-100 py-1 px-2.5 rounded-md">
                      <Building2 size={12} className="text-slate-400" />
                      <span>Unit: {property?.name || "Multiple / Generic"}</span>
                    </div>

                    {tenant && (
                      <div className="flex items-center space-x-1.5 bg-slate-50 border border-slate-100 py-1 px-2.5 rounded-md">
                        <UserCircle size={12} className="text-slate-400" />
                        <span>Resident: {tenant.name} ({tenant.phone || "No Phone"})</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Operations dispatcher right side */}
                <div className="flex flex-row md:flex-col items-center md:items-end justify-between md:justify-center border-t md:border-t-0 border-slate-100 pt-4.5 md:pt-0 shrink-0 gap-3">
                  <div className="text-left md:text-right">
                    <span className="text-3xs text-slate-400 uppercase tracking-wider font-semibold block">Set Status:</span>
                    <div className="flex gap-1.5 mt-1.5">
                      {m.status !== "In Progress" && m.status !== "Resolved" && (
                        <button 
                          onClick={() => handleStatusChange(m.id, "In Progress")}
                          className="bg-amber-50 hover:bg-amber-100 text-amber-805 font-bold text-xxs px-2.5 py-1 rounded border border-amber-250 flex items-center space-x-1 hover:scale-102 active:scale-98 transition-all"
                        >
                          <Play size={10} className="fill-amber-600 border-none" />
                          <span>Dispatch Tech</span>
                        </button>
                      )}

                      {m.status !== "Resolved" && (
                        <button 
                          onClick={() => handleStatusChange(m.id, "Resolved")}
                          className="bg-emerald-50 hover:bg-emerald-110 text-emerald-805 font-bold text-xxs px-2.5 py-1 rounded border border-emerald-250 flex items-center space-x-1 hover:scale-102 active:scale-98 transition-all animate-pulse"
                        >
                          <Check size={10} />
                          <span>Mark Resolved</span>
                        </button>
                      )}
                      
                      {m.status === "Resolved" && (
                        <span className="text-xxs font-medium text-emerald-700 bg-emerald-50 py-1 px-2.5 rounded border border-emerald-100 flex items-center">
                          <CheckCircle2 size={12} className="mr-1 text-emerald-500" />
                          Completed Claim
                        </span>
                      )}
                    </div>
                  </div>

                  <button 
                    onClick={() => onSelectTab("ai", "Maintenance", m)}
                    className="text-xxs font-bold text-indigo-700 bg-indigo-50 border border-indigo-100 hover:bg-indigo-100 py-1.5 px-3 rounded-md flex items-center space-x-1"
                  >
                    <Wrench size={11} />
                    <span>Liaise Trade Contractor AI</span>
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* MODAL SYSTEM */}
      {isFormOpen && (
        <div className="fixed inset-0 bg-slate-950/40 backdrop-blur-xs z-50 flex justify-end animate-fadeIn" id="maintenance-modal">
          <div className="w-full max-w-md bg-white h-full shadow-2xl flex flex-col justify-between overflow-y-auto w-md">
            
            <div className="p-5 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h2 className="font-bold text-slate-950 text-base font-bold">Log Maintenance Ticket</h2>
                <p className="text-slate-400 text-xs">Record resident complaints or inspections</p>
              </div>
              <button onClick={() => setIsFormOpen(false)} className="text-slate-400 hover:text-slate-650">
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-5 space-y-4 flex-1">
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">Affected Property</label>
                <select 
                  value={selectedPropertyId}
                  onChange={(e) => handlePropertyChange(e.target.value)}
                  className="w-full text-sm border border-slate-200 focus:border-indigo-500 bg-white rounded-lg px-3 py-2.5 outline-hidden text-slate-900 font-semibold"
                  required
                >
                  <option value="">-- Select Property Unit --</option>
                  {properties.map(p => (
                    <option key={p.id} value={p.id}>{p.name}</option>
                  ))}
                </select>
              </div>

              {selectedPropertyId && (
                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">Reporting Tenant (Optional Link)</label>
                  <select 
                    value={selectedTenantId}
                    onChange={(e) => setSelectedTenantId(e.target.value)}
                    className="w-full text-sm border border-slate-200 focus:border-indigo-500 bg-white rounded-lg px-3 py-2.5 outline-hidden text-slate-900 text-xs"
                  >
                    <option value="">-- No linked tenant reporting --</option>
                    {tenants.filter(t => t.propertyId === selectedPropertyId).map(t => (
                      <option key={t.id} value={t.id}>{t.name} ({t.phone})</option>
                    ))}
                  </select>
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">Problem / Ticket Headline</label>
                <input 
                  type="text"
                  placeholder="e.g. Garbage disposal buzzing but locked"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full text-sm border border-slate-200 focus:border-indigo-500 bg-white rounded-lg px-3 py-2.5 outline-hidden text-slate-900"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">Request Severity Priority</label>
                <select 
                  value={priority}
                  onChange={(e) => setPriority(e.target.value as any)}
                  className="w-full text-sm border border-slate-200 focus:border-indigo-500 bg-white rounded-lg px-3 py-2.5 outline-hidden text-slate-950 font-medium"
                >
                  <option value="Low">Low - cosmetic / future inspect</option>
                  <option value="Medium">Medium - functional inconvenience</option>
                  <option value="High">High - structural appliance dead</option>
                  <option value="Emergency">Emergency - flood, fire, security breach</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">Detailed Complaint Description</label>
                <textarea 
                  placeholder="Include context such as appliance make/model, frequency, water flow access, lockboxes..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  rows={4}
                  className="w-full text-sm border border-slate-200 bg-white focus:border-indigo-500 rounded-lg p-3 outline-hidden text-slate-905 resize-none"
                  required
                />
              </div>

            </form>

            <div className="p-5 border-t border-slate-100 bg-slate-50 flex justify-end space-x-3">
              <button 
                type="button" 
                onClick={() => setIsFormOpen(false)}
                className="px-4 py-2 border border-slate-200 rounded-lg text-slate-700 text-sm font-medium hover:bg-slate-100"
              >
                Cancel
              </button>
              <button 
                onClick={handleSubmit}
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-semibold transition-colors"
                disabled={loading}
              >
                Dispatch Ticket
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
