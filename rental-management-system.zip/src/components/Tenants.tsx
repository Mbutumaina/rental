import React, { useState } from "react";
import { 
  Users, 
  UserPlus, 
  FileText, 
  Plus, 
  Trash2, 
  Edit3, 
  X, 
  CheckCircle2, 
  Calendar, 
  ExternalLink,
  ShieldAlert,
  Building2,
  Sparkles
} from "lucide-react";
import { Property, Tenant, Lease } from "../types";

interface TenantsProps {
  tenants: Tenant[];
  properties: Property[];
  leases: Lease[];
  onAddTenant: (tenant: Omit<Tenant, "id" | "createdAt">) => Promise<void>;
  onUpdateTenant: (id: string, tenant: Partial<Tenant>) => Promise<void>;
  onDeleteTenant: (id: string) => Promise<void>;
  onCreateLease: (lease: Omit<Lease, "id" | "createdAt">) => Promise<void>;
  onUpdateLease: (id: string, lease: Partial<Lease>) => Promise<void>;
  onDeleteLease: (id: string) => Promise<void>;
  onSelectTab: (tab: string, contextType?: string, contextData?: any) => void;
}

export default function Tenants({ 
  tenants, 
  properties, 
  leases,
  onAddTenant,
  onUpdateTenant,
  onDeleteTenant,
  onCreateLease,
  onUpdateLease,
  onDeleteLease,
  onSelectTab
}: TenantsProps) {
  const [activeSubTab, setActiveSubTab] = useState<"tenants" | "leases">("tenants");
  const [isTenantFormOpen, setIsTenantFormOpen] = useState(false);
  const [isLeaseFormOpen, setIsLeaseFormOpen] = useState(false);
  
  // State for Tenant Form
  const [editingTenant, setEditingTenant] = useState<Tenant | null>(null);
  const [tName, setTName] = useState("");
  const [tEmail, setTEmail] = useState("");
  const [tPhone, setTPhone] = useState("");
  const [tStatus, setTStatus] = useState<"Active" | "Past" | "Applicant">("Applicant");
  const [tPropertyId, setTPropertyId] = useState("");

  // State for Lease Form
  const [editingLease, setEditingLease] = useState<Lease | null>(null);
  const [lPropertyId, setLPropertyId] = useState("");
  const [lTenantId, setLTenantId] = useState("");
  const [lStartDate, setLStartDate] = useState("");
  const [lEndDate, setLEndDate] = useState("");
  const [lRentAmount, setLRentAmount] = useState("");
  const [lDepositAmount, setLDepositAmount] = useState("");
  const [lStatus, setLStatus] = useState<"Active" | "Pending" | "Expired" | "Terminated">("Active");
  const [lTerms, setLTerms] = useState("");

  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");

  // Maps for efficient ID-to-Name lookups
  const propertyMap = React.useMemo(() => new Map(properties.map(p => [p.id, p])), [properties]);
  const tenantMap = React.useMemo(() => new Map(tenants.map(t => [t.id, t])), [tenants]);

  // Handle Tenant CRUD
  const handleOpenTenantCreate = () => {
    setEditingTenant(null);
    setTName("");
    setTEmail("");
    setTPhone("");
    setTStatus("Applicant");
    setTPropertyId("");
    setIsTenantFormOpen(true);
  };

  const handleOpenTenantEdit = (tenant: Tenant) => {
    setEditingTenant(tenant);
    setTName(tenant.name);
    setTEmail(tenant.email);
    setTPhone(tenant.phone);
    setTStatus(tenant.status);
    setTPropertyId(tenant.propertyId || "");
    setIsTenantFormOpen(true);
  };

  const handleTenantSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!tName || !tEmail) {
      alert("Name and Email are required properties.");
      return;
    }

    setLoading(true);
    const payload = {
      name: tName,
      email: tEmail,
      phone: tPhone,
      status: tStatus,
      propertyId: tPropertyId || undefined
    };

    try {
      if (editingTenant) {
        await onUpdateTenant(editingTenant.id, payload);
      } else {
        await onAddTenant(payload);
      }
      setIsTenantFormOpen(false);
    } catch (err) {
      console.error(err);
      alert("Uh oh! Failed to save tenant profile.");
    } finally {
      setLoading(false);
    }
  };

  const handleTenantDelete = async (id: string, name: string) => {
    if (confirm(`Remove tenant record for ${name}? This will free up any linked properties.`)) {
      try {
        await onDeleteTenant(id);
      } catch (err) {
        console.error(err);
        alert("Could not remove tenant record.");
      }
    }
  };

  // Handle Lease CRUD
  const handleOpenLeaseCreate = (prefillTenantId?: string) => {
    setEditingLease(null);
    setLTenantId(prefillTenantId || "");
    
    // Auto find empty property
    const vacantProp = properties.find(p => p.status === "Vacant");
    setLPropertyId(vacantProp ? vacantProp.id : "");
    setLStartDate(new Date().toISOString().split("T")[0]);
    
    const oneYearLater = new Date();
    oneYearLater.setFullYear(oneYearLater.getFullYear() + 1);
    setLEndDate(oneYearLater.toISOString().split("T")[0]);
    
    setLRentAmount(vacantProp ? vacantProp.rentAmount.toString() : "1500");
    setLDepositAmount(vacantProp ? vacantProp.rentAmount.toString() : "1500");
    setLStatus("Active");
    setLTerms(
      "1. Rent is due on the 1st of each month. A late fee of $100 applies after the 5th.\n2. Utility fees are structured separate from core base rent.\n3. The Security Deposit will be fully refunded within 21 days of move-out pending final cleaning checks."
    );
    setIsLeaseFormOpen(true);
  };

  const handleOpenLeaseEdit = (lease: Lease) => {
    setEditingLease(lease);
    setLPropertyId(lease.propertyId);
    setLTenantId(lease.tenantId);
    setLStartDate(lease.startDate);
    setLEndDate(lease.endDate);
    setLRentAmount(lease.rentAmount.toString());
    setLDepositAmount(lease.depositAmount.toString());
    setLStatus(lease.status);
    setLTerms(lease.terms);
    setIsLeaseFormOpen(true);
  };

  const handleLeaseSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!lPropertyId || !lTenantId || !lStartDate || !lEndDate || !lRentAmount) {
      alert("Property, Tenant, dates, and Rent amount are required to sign a lease.");
      return;
    }

    setLoading(true);
    const payload = {
      propertyId: lPropertyId,
      tenantId: lTenantId,
      startDate: lStartDate,
      endDate: lEndDate,
      rentAmount: Number(lRentAmount),
      depositAmount: Number(lDepositAmount) || Number(lRentAmount),
      status: lStatus,
      terms: lTerms
    };

    try {
      if (editingLease) {
        await onUpdateLease(editingLease.id, payload);
      } else {
        await onCreateLease(payload);
      }
      setIsLeaseFormOpen(false);
    } catch (err) {
      console.error(err);
      alert("Failed to compile lease contract.");
    } finally {
      setLoading(false);
    }
  };

  const handleLeaseDelete = async (id: string) => {
    if (confirm("Revoke this lease agreement contract?")) {
      try {
        await onDeleteLease(id);
      } catch (err) {
        console.error(err);
        alert("Failed to void rent lease.");
      }
    }
  };

  // Filter lists based on search
  const filteredTenants = tenants.filter(t => 
    t.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    t.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    t.phone.includes(searchTerm)
  );

  const filteredLeases = leases.filter(l => {
    const propName = propertyMap.get(l.propertyId)?.name || "";
    const tenantName = tenantMap.get(l.tenantId)?.name || "";
    return (
      propName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      tenantName.toLowerCase().includes(searchTerm.toLowerCase())
    );
  });

  return (
    <div className="space-y-6 animate-fadeIn" id="tenants-view">
      {/* Header element */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight flex items-center">
            <Users className="mr-2.5 text-indigo-600" size={24} />
            Residents & Lease Contracts
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Maintain active residents database, background application tracking, and automated lease logs.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          {activeSubTab === "tenants" ? (
            <button 
              onClick={handleOpenTenantCreate}
              className="bg-indigo-600 hover:bg-indigo-700 text-white font-medium text-sm px-4 py-2.5 rounded-xl inline-flex items-center shadow-xs transition-colors"
            >
              <UserPlus size={16} className="mr-1.5" />
              Add Resident Account
            </button>
          ) : (
            <button 
              onClick={() => handleOpenLeaseCreate()}
              className="bg-indigo-600 hover:bg-indigo-700 text-white font-medium text-sm px-4 py-2.5 rounded-xl inline-flex items-center shadow-xs transition-colors"
            >
              <Plus size={16} className="mr-1.5" />
              Draw Smart Lease
            </button>
          )}
        </div>
      </div>

      {/* Tabs segment */}
      <div className="flex border-b border-slate-200">
        <button 
          onClick={() => { setActiveSubTab("tenants"); setSearchTerm(""); }}
          className={`pb-3 px-4 text-sm font-semibold border-b-2 transition-colors ${
            activeSubTab === "tenants"
              ? "border-indigo-600 text-indigo-600" 
              : "border-transparent text-slate-500 hover:text-slate-900"
          }`}
        >
          Residents Ledger ({tenants.length})
        </button>
        <button 
          onClick={() => { setActiveSubTab("leases"); setSearchTerm(""); }}
          className={`pb-3 px-4 text-sm font-semibold border-b-2 transition-colors ${
            activeSubTab === "leases"
              ? "border-indigo-600 text-indigo-600" 
              : "border-transparent text-slate-500 hover:text-slate-900"
          }`}
        >
          Leases Portfolio ({leases.length})
        </button>
      </div>

      {/* Control row */}
      <div className="flex bg-white p-4.5 border border-slate-200 rounded-xl max-w-xl">
        <input 
          type="text"
          placeholder={activeSubTab === "tenants" ? "Search tenants by name, email, phone..." : "Search leases by property or resident..."}
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full text-sm text-slate-800 placeholder-slate-400 bg-transparent border-0 outline-hidden focus:ring-0"
        />
      </div>

      {/* LIST CONTENT 1: TENANTS */}
      {activeSubTab === "tenants" && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" id="tenants-grid">
          {filteredTenants.length === 0 ? (
            <div className="bg-slate-50 border border-dashed border-slate-200 rounded-2xl p-12 text-center text-slate-500 col-span-full">
              <Users className="mx-auto text-slate-300 mb-3" size={32} />
              <h3 className="font-semibold text-slate-800 mb-1">No resident records found</h3>
              <p className="text-xs text-slate-400">Add profile or applications to sign.</p>
            </div>
          ) : (
            filteredTenants.map(t => {
              const currentProperty = t.propertyId ? propertyMap.get(t.propertyId) : null;
              const hasLease = leases.some(l => l.tenantId === t.id && l.status === "Active");
              
              return (
                <div 
                  key={t.id}
                  className="bg-white border border-slate-200 rounded-2xl p-5 hover:shadow-xs transition-all flex flex-col justify-between"
                >
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-indigo-50 text-indigo-600 rounded-full flex items-center justify-center font-bold text-sm">
                          {t.name.split(" ").map(n => n[0]).join("").toUpperCase()}
                        </div>
                        <div>
                          <h3 className="font-semibold text-slate-900 text-sm">{t.name}</h3>
                          <p className="text-xxs text-slate-400">Joined {new Date(t.createdAt).toLocaleDateString()}</p>
                        </div>
                      </div>
                      <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xxs font-medium ${
                        t.status === "Active" ? "bg-teal-50 text-teal-700 border border-teal-100" :
                        t.status === "Applicant" ? "bg-indigo-50 text-indigo-700 border border-indigo-100" :
                        "bg-slate-50 text-slate-600 border border-slate-200"
                      }`}>
                        {t.status}
                      </span>
                    </div>

                    <div className="space-y-1.5 text-xs text-slate-600 border-t border-b border-slate-100 py-3">
                      <div className="flex justify-between">
                        <span className="text-slate-400">Email:</span>
                        <span className="font-medium text-slate-800">{t.email}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">Phone:</span>
                        <span className="font-medium text-slate-800">{t.phone || "---"}</span>
                      </div>
                      <div className="flex justify-between items-center pt-2">
                        <span className="text-slate-400">Rented Unit:</span>
                        {currentProperty ? (
                          <span className="font-semibold text-indigo-600 flex items-center">
                            <Building2 size={12} className="mr-1" />
                            {currentProperty.name}
                          </span>
                        ) : (
                          <span className="text-amber-600 font-medium bg-amber-50 px-1.5 py-0.5 rounded text-xxs">Unassigned</span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 pt-1 flex items-center justify-between gap-2.5">
                    <div className="flex space-x-1">
                      <button 
                        onClick={() => handleOpenTenantEdit(t)}
                        className="p-2 text-slate-500 hover:text-indigo-600 hover:bg-slate-50 rounded-lg transition-colors border border-slate-100"
                        title="Edit profiles"
                      >
                        <Edit3 size={14} />
                      </button>
                      <button 
                        onClick={() => handleTenantDelete(t.id, t.name)}
                        className="p-2 text-slate-500 hover:text-rose-600 hover:bg-slate-50 rounded-lg transition-colors border border-slate-100"
                        title="Delete tenant record"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>

                    <div className="flex gap-1">
                      {!t.propertyId && t.status === "Applicant" && (
                        <button 
                          onClick={() => handleOpenLeaseCreate(t.id)}
                          className="text-xs font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 py-2 px-3 border border-emerald-100 rounded-lg transition-colors flex items-center space-x-1"
                        >
                          <FileText size={12} />
                          <span>Link Lease</span>
                        </button>
                      )}
                      
                      <button 
                        onClick={() => onSelectTab("ai", "Tenant", t)}
                        className="text-xs font-semibold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 py-2 px-3 border border-indigo-100 rounded-lg transition-colors flex items-center space-x-1"
                      >
                        <Sparkles size={11} />
                        <span>AI Mailbox</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}

      {/* LIST CONTENT 2: LEASES */}
      {activeSubTab === "leases" && (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs" id="leases-table-holder">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-sm">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-xs font-bold text-slate-500 uppercase tracking-wider">
                  <th className="p-4">Tenant / Property</th>
                  <th className="p-4">Lease Term Duration</th>
                  <th className="p-4">Monthly Rent</th>
                  <th className="p-4">Security Deposit</th>
                  <th className="p-4">Status Balance</th>
                  <th className="p-4 text-right">Settings</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {filteredLeases.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="text-center py-10 text-slate-400">
                      No active lease contracts registered.
                    </td>
                  </tr>
                ) : (
                  filteredLeases.map(l => {
                    const tenant = tenantMap.get(l.tenantId);
                    const prop = propertyMap.get(l.propertyId);
                    
                    return (
                      <tr key={l.id} className="hover:bg-slate-55/10">
                        <td className="p-4">
                          <div>
                            <span className="font-semibold text-slate-900 block">{tenant?.name || "Terminated User"}</span>
                            <span className="text-xs text-slate-500 flex items-center mt-0.5">
                              <Building2 size={11} className="mr-1 text-slate-450" />
                              {prop?.name || "Unassigned Unit"}
                            </span>
                          </div>
                        </td>
                        <td className="p-4 font-mono text-xs">
                          <div className="flex items-center space-x-1.5 text-slate-800">
                            <Calendar size={13} className="text-slate-400" />
                            <span>{l.startDate}</span>
                            <span className="text-slate-400">→</span>
                            <span>{l.endDate}</span>
                          </div>
                        </td>
                        <td className="p-4 font-semibold text-slate-900">${l.rentAmount}/mo</td>
                        <td className="p-4 text-slate-500">${l.depositAmount}</td>
                        <td className="p-4">
                          <span className={`inline-flex px-2 py-0.5 rounded-full text-xxs font-semibold ${
                            l.status === "Active" ? "bg-teal-50 text-teal-850" :
                            l.status === "Pending" ? "bg-amber-50 text-amber-850 animate-pulse" :
                            "bg-slate-100 text-slate-700"
                          }`}>
                            {l.status}
                          </span>
                        </td>
                        <td className="p-4 text-right">
                          <div className="flex items-center justify-end space-x-1">
                            <button 
                              onClick={() => handleOpenLeaseEdit(l)}
                              className="p-1 px-2.5 text-xs text-indigo-700 bg-indigo-50 border border-indigo-100 hover:bg-indigo-100 font-semibold rounded-lg"
                            >
                              Revise Terms
                            </button>
                            <button 
                              onClick={() => handleLeaseDelete(l.id)}
                              className="p-1.5 text-slate-400 hover:text-rose-600 rounded"
                            >
                              <Trash2 size={14} />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}


      {/* MODAL 1: TENANT REGISTRATION PANEL */}
      {isTenantFormOpen && (
        <div className="fixed inset-0 bg-slate-950/40 backdrop-blur-xs z-50 flex justify-end animate-fadeIn" id="tenant-modal">
          <div className="w-full max-w-md bg-white h-full shadow-2xl flex flex-col justify-between overflow-y-auto">
            
            <div className="p-5 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h2 className="font-bold text-slate-950 text-base">
                  {editingTenant ? "Edit Resident Profile" : "Add Resident Applicant"}
                </h2>
                <p className="text-slate-400 text-xs">Maintain communication credentials</p>
              </div>
              <button onClick={() => setIsTenantFormOpen(false)} className="text-slate-400 hover:text-slate-650">
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleTenantSubmit} className="p-5 space-y-4 flex-1">
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">Full Name</label>
                <input 
                  type="text"
                  placeholder="e.g. Elena Rostova"
                  value={tName}
                  onChange={(e) => setTName(e.target.value)}
                  className="w-full text-sm border border-slate-200 focus:border-indigo-500 bg-white rounded-lg px-3.5 py-2.5 outline-hidden text-slate-905"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">Email Address</label>
                <input 
                  type="email"
                  placeholder="elena@example.com"
                  value={tEmail}
                  onChange={(e) => setTEmail(e.target.value)}
                  className="w-full text-sm border border-slate-200 focus:border-indigo-500 bg-white rounded-lg px-3.5 py-2.5 outline-hidden text-slate-905"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">Phone Number</label>
                <input 
                  type="text"
                  placeholder="(512) 555-0149"
                  value={tPhone}
                  onChange={(e) => setTPhone(e.target.value)}
                  className="w-full text-sm border border-slate-200 focus:border-indigo-500 bg-white rounded-lg px-3.5 py-2.5 outline-hidden text-slate-905"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">Current Status</label>
                <select 
                  value={tStatus}
                  onChange={(e) => setTStatus(e.target.value as any)}
                  className="w-full text-sm border border-slate-200 focus:border-indigo-500 bg-white rounded-lg px-3.5 py-2.5 outline-hidden text-slate-905"
                >
                  <option value="Applicant">Applicant (Screening background check)</option>
                  <option value="Active">Active (Renting Property)</option>
                  <option value="Past">Past Tenant (Archived)</option>
                </select>
              </div>

              {tStatus === "Active" && (
                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">Link to unit property</label>
                  <select 
                    value={tPropertyId}
                    onChange={(e) => setTPropertyId(e.target.value)}
                    className="w-full text-sm border border-slate-200 focus:border-indigo-500 bg-white rounded-lg px-3.5 py-2.5 outline-hidden text-slate-905 text-xs font-semibold"
                  >
                    <option value="">-- Clear linkage / Vacant --</option>
                    {properties.map(p => (
                      <option key={p.id} value={p.id}>
                        {p.name} (${p.rentAmount}/mo - {p.status})
                      </option>
                    ))}
                  </select>
                </div>
              )}
            </form>

            <div className="p-5 border-t border-slate-100 bg-slate-50 flex justify-end space-x-3">
              <button 
                type="button" 
                onClick={() => setIsTenantFormOpen(false)}
                className="px-4 py-2 border border-slate-200 rounded-lg text-slate-700 text-sm font-medium hover:bg-slate-100"
              >
                Cancel
              </button>
              <button 
                onClick={handleTenantSubmit}
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-semibold transition-colors"
              >
                Save Profile
              </button>
            </div>

          </div>
        </div>
      )}


      {/* MODAL 2: DRAW SMART LEASE CONTRACT */}
      {isLeaseFormOpen && (
        <div className="fixed inset-0 bg-slate-950/40 backdrop-blur-xs z-50 flex justify-end animate-fadeIn" id="lease-modal">
          <div className="w-full max-w-xl bg-white h-full shadow-2xl flex flex-col justify-between overflow-y-auto">
            
            <div className="p-5 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h2 className="font-bold text-slate-950 text-base">
                  {editingLease ? "Revise Signed Lease" : "Formulate Smart Lease Agreement"}
                </h2>
                <p className="text-slate-400 text-xs">Design legally resilient property management covenants</p>
              </div>
              <button onClick={() => setIsLeaseFormOpen(false)} className="text-slate-400 hover:text-slate-650">
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleLeaseSubmit} className="p-5 space-y-4 flex-1">
              
              {/* Entity connection fields */}
              <div className="grid grid-cols-2 gap-3 pb-2 border-b border-slate-100">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">Renting Resident</label>
                  <select 
                    value={lTenantId}
                    onChange={(e) => setLTenantId(e.target.value)}
                    disabled={editingLease !== null}
                    className="w-full text-sm border border-slate-200 focus:ring-1 focus:ring-indigo-500 bg-white rounded-lg px-2.5 py-2 text-slate-900 disabled:bg-slate-50 font-medium"
                    required
                  >
                    <option value="">-- Choose Tenant --</option>
                    {tenants.map(t => (
                      <option key={t.id} value={t.id}>{t.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">Designated Unit</label>
                  <select 
                    value={lPropertyId}
                    onChange={(e) => {
                      setLPropertyId(e.target.value);
                      const prop = propertyMap.get(e.target.value);
                      if (prop) {
                        setLRentAmount(prop.rentAmount.toString());
                        setLDepositAmount(prop.rentAmount.toString());
                      }
                    }}
                    disabled={editingLease !== null}
                    className="w-full text-sm border border-slate-200 focus:ring-1 focus:ring-indigo-500 bg-white rounded-lg px-2.5 py-2 text-slate-900 disabled:bg-slate-50 font-medium"
                    required
                  >
                    <option value="">-- Choose Vacant Space --</option>
                    {properties.map(p => (
                      <option key={p.id} value={p.id}>{p.name} (${p.rentAmount}/mo)</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Lease Dates */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">Start Date</label>
                  <input 
                    type="date"
                    value={lStartDate}
                    onChange={(e) => setLStartDate(e.target.value)}
                    className="w-full text-sm border border-slate-200 bg-white rounded-lg px-3 py-2 outline-hidden text-slate-900"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">Expiration Date</label>
                  <input 
                    type="date"
                    value={lEndDate}
                    onChange={(e) => setLEndDate(e.target.value)}
                    className="w-full text-sm border border-slate-200 bg-white rounded-lg px-3 py-2 outline-hidden text-slate-900"
                    required
                  />
                </div>
              </div>

              {/* Monies */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">Monthly Rent ($)</label>
                  <input 
                    type="number"
                    value={lRentAmount}
                    onChange={(e) => setLRentAmount(e.target.value)}
                    className="w-full text-sm border border-slate-200 bg-white rounded-lg px-3 py-2 outline-hidden text-slate-900"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">Security Deposit ($)</label>
                  <input 
                    type="number"
                    value={lDepositAmount}
                    onChange={(e) => setLDepositAmount(e.target.value)}
                    className="w-full text-sm border border-slate-200 bg-white rounded-lg px-3 py-2 outline-hidden text-slate-900"
                  />
                </div>
              </div>

              {/* Status */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">Contract State</label>
                <select 
                  value={lStatus}
                  onChange={(e) => setLStatus(e.target.value as any)}
                  className="w-full text-sm border border-slate-200 bg-white rounded-lg px-3 py-2 outline-hidden text-slate-900"
                >
                  <option value="Active">Active Lease (Fully Executed)</option>
                  <option value="Pending">Pending Signature</option>
                  <option value="Expired">Expired</option>
                  <option value="Terminated">Early Termination</option>
                </select>
              </div>

              {/* Custom terms */}
              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider">Lease Terms & Covenants</label>
                  <button 
                    type="button"
                    onClick={() => {
                      if (lTenantId) {
                        const t = tenantMap.get(lTenantId);
                        const p = propertyMap.get(lPropertyId);
                        onSelectTab("ai", "LeaseDraft", { tenant: t, property: p });
                        setIsLeaseFormOpen(false);
                      } else {
                        alert("Please select a tenant and property first to draft customized terms using Gemini.");
                      }
                    }}
                    className="inline-flex items-center text-xs text-indigo-700 hover:text-indigo-800 font-bold bg-indigo-50 px-2 py-1 rounded border border-indigo-100"
                  >
                    <Sparkles size={11} className="mr-1" />
                    Autofill with Gemini AI
                  </button>
                </div>
                <textarea 
                  value={lTerms}
                  onChange={(e) => setLTerms(e.target.value)}
                  rows={6}
                  className="w-full text-xs font-mono border border-slate-200 bg-slate-50 rounded-lg p-3 outline-hidden text-slate-800 leading-relaxed resize-none"
                  required
                />
              </div>

            </form>

            <div className="p-5 border-t border-slate-100 bg-slate-50 flex justify-end space-x-3">
              <button 
                type="button" 
                onClick={() => setIsLeaseFormOpen(false)}
                className="px-4 py-2 border border-slate-200 rounded-lg text-slate-700 text-sm font-medium hover:bg-slate-100"
              >
                Cancel
              </button>
              <button 
                onClick={handleLeaseSubmit}
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-semibold transition-colors"
                disabled={loading}
              >
                Sign Contract
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
