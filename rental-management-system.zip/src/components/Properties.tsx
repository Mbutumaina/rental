import React, { useState } from "react";
import { 
  Building2, 
  MapPin, 
  Bed, 
  Bath, 
  DollarSign, 
  Plus, 
  Trash2, 
  Edit3, 
  X, 
  Sparkles,
  Info 
} from "lucide-react";
import { Property } from "../types";

interface PropertiesProps {
  properties: Property[];
  onAddProperty: (property: Omit<Property, "id" | "createdAt">) => Promise<void>;
  onUpdateProperty: (id: string, property: Partial<Property>) => Promise<void>;
  onDeleteProperty: (id: string) => Promise<void>;
  onSelectTab: (tab: string, contextType?: string, contextData?: any) => void;
}

export default function Properties({ 
  properties, 
  onAddProperty, 
  onUpdateProperty, 
  onDeleteProperty,
  onSelectTab
}: PropertiesProps) {
  
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingProp, setEditingProp] = useState<Property | null>(null);

  // Form Fields
  const [name, setName] = useState("");
  const [address, setAddress] = useState("");
  const [type, setType] = useState<"Apartment" | "House" | "Studio" | "Commercial">("Apartment");
  const [rentAmount, setRentAmount] = useState("");
  const [bedrooms, setBedrooms] = useState("");
  const [bathrooms, setBathrooms] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const [description, setDescription] = useState("");
  const [status, setStatus] = useState<"Occupied" | "Vacant" | "Maintenance">("Vacant");

  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");

  const handleOpenCreateForm = () => {
    setEditingProp(null);
    setName("");
    setAddress("");
    setType("Apartment");
    setRentAmount("");
    setBedrooms("");
    setBathrooms("");
    setImageUrl("");
    setDescription("");
    setStatus("Vacant");
    setIsFormOpen(true);
  };

  const handleOpenEditForm = (prop: Property) => {
    setEditingProp(prop);
    setName(prop.name);
    setAddress(prop.address);
    setType(prop.type);
    setRentAmount(prop.rentAmount.toString());
    setBedrooms(prop.bedrooms.toString());
    setBathrooms(prop.bathrooms.toString());
    setImageUrl(prop.imageUrl);
    setDescription(prop.description || "");
    setStatus(prop.status);
    setIsFormOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !address || !rentAmount) {
      alert("Name, Address, and Rent Amount are required.");
      return;
    }

    setLoading(true);
    const payload = {
      name,
      address,
      type,
      rentAmount: Number(rentAmount),
      bedrooms: Number(bedrooms) || 1,
      bathrooms: Number(bathrooms) || 1,
      imageUrl: imageUrl || "https://images.unsplash.com/photo-1564013799919-ab600027ffc6?auto=format&fit=crop&w=800&q=80",
      description,
      status
    };

    try {
      if (editingProp) {
        await onUpdateProperty(editingProp.id, payload);
      } else {
        await onAddProperty(payload);
      }
      setIsFormOpen(false);
    } catch (err) {
      console.error(err);
      alert("Uh oh, failed to register property layout. Check inputs.");
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: string, propName: string) => {
    if (confirm(`Are you absolutely sure you want to delete ${propName}?`)) {
      try {
        await onDeleteProperty(id);
      } catch (err) {
        console.error(err);
        alert("Could not complete property deletion.");
      }
    }
  };

  const filteredProperties = properties.filter(p =>
    p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.address.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.type.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6 animate-fadeIn" id="properties-view">
      {/* Header and controller */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight flex items-center">
            <Building2 className="mr-2.5 text-indigo-600" size={24} />
            Properties Portfolio
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Displaying {filteredProperties.length} of {properties.length} active property structures.
          </p>
        </div>
        
        <button 
          onClick={handleOpenCreateForm}
          className="bg-indigo-600 hover:bg-indigo-700 text-white font-medium text-sm px-4.5 py-2.5 rounded-xl inline-flex items-center self-start sm:self-auto shadow-xs transition-colors"
        >
          <Plus size={16} className="mr-1.5" />
          Add Property Unit
        </button>
      </div>

      {/* Filter and search block */}
      <div className="flex bg-white p-4.5 border border-slate-200 rounded-xl max-w-xl">
        <input 
          type="text"
          placeholder="Search by name, address, layout type..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full text-sm text-slate-800 placeholder-slate-400 bg-transparent border-0 outline-hidden focus:ring-0"
        />
      </div>

      {/* Grid Display */}
      {filteredProperties.length === 0 ? (
        <div className="bg-slate-50 border border-dashed border-slate-200 rounded-2xl p-12 text-center text-slate-500">
          <Building2 className="mx-auto text-slate-300 mb-3" size={32} />
          <h3 className="font-semibold text-slate-800 mb-1">No property units match your query</h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            Try adjusting your search criteria, or click "Add Property Unit" above to populate a new luxury apartment or suburban townhouse.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6" id="properties-grid">
          {filteredProperties.map(p => (
            <div 
              key={p.id}
              className="bg-white border border-slate-200 rounded-2xl overflow-hidden hover:shadow-md transition-shadow group flex flex-col justify-between"
            >
              <div>
                {/* Header image */}
                <div className="relative h-48 bg-slate-100 overflow-hidden">
                  <img 
                    src={p.imageUrl} 
                    alt={p.name}
                    className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute top-3 right-3">
                    <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold shadow-xs ${
                      p.status === "Occupied" ? "bg-teal-500 text-white" :
                      p.status === "Maintenance" ? "bg-rose-500 text-white" :
                      "bg-amber-500 text-white"
                    }`}>
                      {p.status}
                    </span>
                  </div>
                </div>

                {/* Body Details */}
                <div className="p-5 space-y-4">
                  <div>
                    <span className="text-[10px] font-semibold uppercase tracking-wider text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full">
                      {p.type}
                    </span>
                    <h3 className="font-semibold text-slate-900 mt-2 text-base leading-snug truncate">
                      {p.name}
                    </h3>
                    <p className="text-xs text-slate-500 flex items-center mt-1">
                      <MapPin size={12} className="mr-1 shrink-0 text-slate-400" />
                      <span className="truncate">{p.address}</span>
                    </p>
                  </div>

                  {/* Bed/Bath & amenities */}
                  <div className="flex items-center gap-4 text-xs font-medium text-slate-600 bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                    <div className="flex items-center">
                      <Bed size={14} className="mr-1.5 text-slate-400" />
                      <span>{p.bedrooms} {p.bedrooms === 1 ? "Bed" : "Beds"}</span>
                    </div>
                    <div className="h-4 w-px bg-slate-200"></div>
                    <div className="flex items-center">
                      <Bath size={14} className="mr-1.5 text-slate-400" />
                      <span>{p.bathrooms} {p.bathrooms === 1 ? "Bath" : "Baths"}</span>
                    </div>
                    <div className="h-4 w-px bg-slate-200"></div>
                    <div className="flex items-center">
                      <DollarSign size={14} className="text-slate-400" />
                      <span className="font-semibold text-slate-900">${p.rentAmount}/mo</span>
                    </div>
                  </div>

                  {p.description && (
                    <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
                      {p.description}
                    </p>
                  )}
                </div>
              </div>

              {/* Action row footer */}
              <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
                <div className="flex items-center space-x-1">
                  <button 
                    onClick={() => handleOpenEditForm(p)}
                    className="p-2 text-slate-500 hover:text-indigo-600 hover:bg-white rounded-lg transition-colors border border-transparent hover:border-slate-200"
                    title="Edit property configuration"
                  >
                    <Edit3 size={15} />
                  </button>
                  <button 
                    onClick={() => handleDelete(p.id, p.name)}
                    className="p-2 text-slate-500 hover:text-rose-600 hover:bg-white rounded-lg transition-colors border border-transparent hover:border-slate-200"
                    title="Remove from portfolio"
                  >
                    <Trash2 size={15} />
                  </button>
                </div>

                <div className="flex space-x-1.5">
                  <button 
                    onClick={() => onSelectTab("ai", "Property", p)}
                    className="text-xs font-semibold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 py-1.5 px-3 rounded-lg flex items-center space-x-1 transition-colors border border-indigo-100"
                  >
                    <Sparkles size={11} />
                    <span>Liaise AI</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Slide out Modal Panel / Overlay form */}
      {isFormOpen && (
        <div className="fixed inset-0 bg-slate-950/40 backdrop-blur-xs z-50 flex justify-end animate-fadeIn" id="property-form-modal">
          <div className="w-full max-w-md bg-white h-full shadow-2xl flex flex-col justify-between overflow-y-auto">
            
            {/* Modal header */}
            <div className="p-5 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h2 className="font-bold text-slate-950 text-base">
                  {editingProp ? `Configure Unit - ${editingProp.name}` : "Register Property Layout"}
                </h2>
                <p className="text-slate-400 text-xs">Maintain correct specifications in the database</p>
              </div>
              <button 
                onClick={() => setIsFormOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-100"
              >
                <X size={18} />
              </button>
            </div>

            {/* Modal form */}
            <form onSubmit={handleSubmit} className="p-5 space-y-4 flex-1">
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">Property / Unit Name</label>
                <input 
                  type="text"
                  placeholder="e.g. Cedar Meadow Townhouse #4"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full text-sm border border-slate-200 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 bg-white rounded-lg px-3.5 py-2.5 outline-hidden text-slate-900"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">Postal Address</label>
                <input 
                  type="text"
                  placeholder="e.g. 839 Whitetail Lane, Austin, TX 78745"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full text-sm border border-slate-200 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 bg-white rounded-lg px-3.5 py-2.5 outline-hidden text-slate-900"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">Property Type</label>
                  <select 
                    value={type}
                    onChange={(e) => setType(e.target.value as any)}
                    className="w-full text-sm border border-slate-200 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 bg-white rounded-lg px-3.5 py-2.5 outline-hidden text-slate-900"
                  >
                    <option value="Apartment">Apartment</option>
                    <option value="House">House</option>
                    <option value="Studio">Studio</option>
                    <option value="Commercial">Commercial</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">Monthly Rent ($)</label>
                  <input 
                    type="number"
                    placeholder="2400"
                    value={rentAmount}
                    onChange={(e) => setRentAmount(e.target.value)}
                    className="w-full text-sm border border-slate-200 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 bg-white rounded-lg px-3.5 py-2.5 outline-hidden text-slate-900"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">Bedrooms Count</label>
                  <input 
                    type="number"
                    placeholder="3"
                    value={bedrooms}
                    onChange={(e) => setBedrooms(e.target.value)}
                    className="w-full text-sm border border-slate-200 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 bg-white rounded-lg px-3.5 py-2.5 outline-hidden text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">Bathrooms Count</label>
                  <input 
                    type="number"
                    step="0.5"
                    placeholder="2.5"
                    value={bathrooms}
                    onChange={(e) => setBathrooms(e.target.value)}
                    className="w-full text-sm border border-slate-200 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 bg-white rounded-lg px-3.5 py-2.5 outline-hidden text-slate-900"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">Status Condition</label>
                <select 
                  value={status}
                  onChange={(e) => setStatus(e.target.value as any)}
                  className="w-full text-sm border border-slate-200 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 bg-white rounded-lg px-3.5 py-2.5 outline-hidden text-slate-900"
                >
                  <option value="Vacant">Vacant</option>
                  <option value="Occupied">Occupied</option>
                  <option value="Maintenance">Maintenance</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">Cover Image (URL Optional)</label>
                <input 
                  type="text"
                  placeholder="https://images.unsplash.com/photo-..."
                  value={imageUrl}
                  onChange={(e) => setImageUrl(e.target.value)}
                  className="w-full text-sm border border-slate-200 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 bg-white rounded-lg px-3.5 py-2.5 outline-hidden text-slate-900 text-xs"
                />
                <span className="text-xxs text-slate-400 mt-1 block">Leave empty to auto-assign a high-quality, default architectural photo.</span>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">Interior Description</label>
                <textarea 
                  placeholder="Summarize aesthetic touches, included appliances, pool rules or keys..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  rows={3}
                  className="w-full text-sm border border-slate-200 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 bg-white rounded-lg px-3.5 py-2.5 outline-hidden text-slate-900 resize-none"
                />
              </div>
            </form>

            {/* Modal actions */}
            <div className="p-5 border-t border-slate-100 bg-slate-50 flex items-center justify-end space-x-3">
              <button 
                type="button"
                onClick={() => setIsFormOpen(false)}
                className="px-4 py-2 border border-slate-200 rounded-lg text-slate-700 text-sm font-medium hover:bg-slate-100 hover:text-slate-950 transition-colors"
                disabled={loading}
              >
                Cancel
              </button>
              <button 
                onClick={handleSubmit}
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-medium shadow-xs focus:ring-2 focus:ring-indigo-500/20 transition-colors"
                disabled={loading}
              >
                {loading ? "Syncing..." : editingProp ? "Save Changes" : "Create Layout"}
              </button>
            </div>

          </div>
        </div>
      )}
    </div>
  );
}
