import React, { useState, useEffect, useRef } from "react";
import { 
  Sparkles, 
  Send, 
  Bot, 
  User, 
  RotateCw, 
  FileText, 
  Mail, 
  Wrench,
  ChevronRight,
  Info
} from "lucide-react";
import { Message } from "../types";

interface AIAssistantProps {
  initialContextType?: string;
  initialContextData?: any;
  onClearContext?: () => void;
}

export default function AIAssistant({ 
  initialContextType, 
  initialContextData,
  onClearContext 
}: AIAssistantProps) {

  const [messages, setMessages] = useState<Message[]>([
    {
      role: "model",
      text: "Greetings. I am the Rental Intelligence Assistant, powered by Gemini. I specialize in property management administration, writing lease contracts, drafting respectful communication alerts, and solving landlord logistics.\n\nHow can I help you streamline your tenancy records today?",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);

  const [inputValue, setInputValue] = useState("");
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // If redirected with entity context (e.g. click "Liaise AI" on property or tenant)
  useEffect(() => {
    if (initialContextType && initialContextData) {
      let promptText = "";
      if (initialContextType === "Property") {
        promptText = `Provide a professional Craigslist landing write-up for my property "${initialContextData.name}" located at "${initialContextData.address}" with rent priced at $${initialContextData.rentAmount}/mo. Highlight its ${initialContextData.bedrooms} bedrooms, ${initialContextData.bathrooms} bathrooms, and the layout: ${initialContextData.description || "suburban townhouse structure"}.`;
      } else if (initialContextType === "Tenant") {
        promptText = `Draft a polite, professional 30-day lease-renewal reminder email to send my resident "${initialContextData.name}" (${initialContextData.email}) regarding unit details. Ask them if they intend to extend and congratulate them on a great tenancy.`;
      } else if (initialContextType === "Maintenance") {
        promptText = `Draft a dispatch order message to sync with our plumbing trade contractor regarding this tenant report: "${initialContextData.title}" - Description: "${initialContextData.description}". Specify urgency priority: [${initialContextData.priority}].`;
      } else if (initialContextType === "LeaseDraft") {
        promptText = `Formulate a comprehensive custom lease agreement 'Terms and Covenants' section for tenant "${initialContextData.tenant?.name || "the Tenant"}" renting property "${initialContextData.property?.name || "the Property"}" at a base rate of $${initialContextData.property?.rentAmount || "1800"}/month. Draft clauses for lawn maintenance, trash sorting, and late fee consequences.`;
      }

      if (promptText) {
        setInputValue(promptText);
      }
    }
  }, [initialContextType, initialContextData]);

  // Adjust scroll position during dialog entries
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  const handleSendMessage = async (customPrompt?: string) => {
    const textToSend = (customPrompt || inputValue).trim();
    if (!textToSend) return;

    if (!customPrompt) {
      setInputValue("");
    }

    const newUserMessage: Message = {
      role: "user",
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, newUserMessage]);
    setLoading(true);

    try {
      const response = await fetch("/api/assistant", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: [...messages, newUserMessage],
          contextType: initialContextType,
          contextData: initialContextData
        })
      });

      if (!response.ok) {
        throw new Error("Assistant is unresponsive on the gateway.");
      }

      const result = await response.json();
      
      const assistantMessage: Message = {
        role: "model",
        text: result.text || "Processed correctly, but no response body was generated.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages(prev => [...prev, assistantMessage]);
    } catch (err) {
      console.error(err);
      setMessages(prev => [...prev, {
        role: "model",
        text: "🚨 Integration Error: Failed to contact Gemini on the server. Please verify process logs.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }]);
    } finally {
      setLoading(false);
      if (onClearContext) {
        onClearContext();
      }
    }
  };

  const handleReset = () => {
    setMessages([
      {
        role: "model",
        text: "Greetings. I am the Rental Intelligence Assistant, powered by Gemini. I specialize in property management administration, writing lease contracts, drafting respectful communication alerts, and solving landlord logistics.\n\nHow can I help you streamline your tenancy records today?",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }
    ]);
    if (onClearContext) {
      onClearContext();
    }
  };

  // Render basic markdown formatting securely (Bold headers, line breaks, ticks)
  const formatText = (text: string) => {
    return text.split("\n").map((line, idx) => {
      // Bullet items
      if (line.trim().startsWith("- ") || line.trim().startsWith("* ")) {
        return (
          <li key={idx} className="ml-5 list-disc text-sm text-slate-800 my-1">
            {line.trim().substring(2)}
          </li>
        );
      }
      // Subject or template headings
      if (line.trim().startsWith("Subject:") || line.trim().startsWith("Dear")) {
        return (
          <p key={idx} className="font-semibold text-slate-900 text-sm my-1">
            {line}
          </p>
        );
      }
      return (
        <p key={idx} className="text-sm text-slate-700 leading-relaxed min-h-[1rem]">
          {line}
        </p>
      );
    });
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 h-[calc(100vh-14rem)] min-h-[500px]" id="ai-assistant-view">
      
      {/* LEFT CHIP RACK: FAST ACTIONS (4 cols) */}
      <div className="lg:col-span-4 bg-slate-900 text-white rounded-2xl p-6 flex flex-col justify-between">
        <div className="space-y-6">
          <div>
            <div className="flex items-center space-x-2">
              <Sparkles className="text-teal-400" size={20} />
              <h2 className="font-bold text-lg tracking-tight">AI Dispatcher Desk</h2>
            </div>
            <p className="text-slate-300 text-xs mt-2 leading-relaxed">
              Use predictive AI models to write legal copy and notify residents in a single click.
            </p>
          </div>

          <div className="space-y-3">
            <span className="text-3xs uppercase tracking-widest text-slate-400 font-bold block mb-1">Common blueprints:</span>
            
            <button 
              onClick={() => handleSendMessage("Draft a warning notice about late rent penalties of $100 after the 5th based on normal rental laws.")}
              className="w-full text-left bg-slate-800 hover:bg-slate-750 border border-slate-700 hover:border-slate-600 p-3 rounded-xl transition-all"
            >
              <div className="flex items-start space-x-2.5">
                <Mail className="text-teal-400 shrink-0 mt-0.5" size={14} />
                <div>
                  <h4 className="text-xs font-semibold">Late Rent Warning Notice</h4>
                  <p className="text-super-xs text-slate-400 mt-1">Prompt standard due penalty warnings.</p>
                </div>
              </div>
            </button>

            <button 
              onClick={() => handleSendMessage("Draft a custom letter welcoming a new tenant and explaining trash sorting, parking space rules, and keeping common hallways completely clear.")}
              className="w-full text-left bg-slate-800 hover:bg-slate-750 border border-slate-700 hover:border-slate-600 p-3 rounded-xl transition-all"
            >
              <div className="flex items-start space-x-2.5">
                <FileText className="text-teal-400 shrink-0 mt-0.5" size={14} />
                <div>
                  <h4 className="text-xs font-semibold">Tenant Welcome Guidebook</h4>
                  <p className="text-super-xs text-slate-400 mt-1">Review guidelines and setup terms.</p>
                </div>
              </div>
            </button>

            <button 
              onClick={() => handleSendMessage("Draft a legal notice of plumbing inspection required. We will need access to crawlspaces on upcoming Friday between 10am and 2pm.")}
              className="w-full text-left bg-slate-800 hover:bg-slate-750 border border-slate-700 hover:border-slate-600 p-3 rounded-xl transition-all"
            >
              <div className="flex items-start space-x-2.5">
                <Wrench className="text-teal-400 shrink-0 mt-0.5" size={14} />
                <div>
                  <h4 className="text-xs font-semibold">Crawlspace Access Notice</h4>
                  <p className="text-super-xs text-slate-400 mt-1">Notify 24-hr advance entry request.</p>
                </div>
              </div>
            </button>
          </div>
        </div>

        {/* Selected Context details banner */}
        {initialContextType && initialContextData && (
          <div className="mt-4 bg-teal-950/40 border border-teal-800 text-teal-200 rounded-xl p-3.5 flex items-start space-x-2.5">
            <Info size={16} className="shrink-0 mt-0.5 text-teal-400" />
            <div>
              <span className="text-3xs uppercase font-bold text-teal-400">Context active:</span>
              <p className="text-xs font-semibold mt-0.5">{initialContextType}: {initialContextData.name || "Spec terms"}</p>
              <p className="text-super-xs text-teal-300 mt-0.5 truncate max-w-[200px]">Data values auto-bound in prompt context.</p>
            </div>
          </div>
        )}
      </div>

      {/* RIGHT DISPLAY: DIALOG & CONTROLLERS (8 cols) */}
      <div className="lg:col-span-8 bg-white border border-slate-200 rounded-2xl flex flex-col justify-between overflow-hidden shadow-xs">
        
        {/* Assistant Header */}
        <div className="bg-slate-50 border-b border-slate-100 p-4.5 flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="w-9 h-9 bg-indigo-100 text-indigo-700 rounded-lg flex items-center justify-center">
              <Bot size={18} />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-sm">Rental Intelligence Agent</h3>
              <span className="text-[10px] text-teal-600 font-semibold flex items-center">
                <span className="w-1.5 h-1.5 bg-teal-500 rounded-full mr-1 animate-pulse"></span>
                Gemini 3.5 Flash Connected
              </span>
            </div>
          </div>

          <button 
            onClick={handleReset}
            className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-slate-100 rounded-lg transition-colors border border-slate-250"
            title="Reset conversation"
          >
            <RotateCw size={14} />
          </button>
        </div>

        {/* Message body */}
        <div className="flex-1 p-5 overflow-y-auto space-y-4 max-h-[400px]">
          {messages.map((m, idx) => (
            <div 
              key={idx}
              className={`flex items-start space-x-3 max-w-[85%] ${m.role === "user" ? "ml-auto flex-row-reverse space-x-reverse" : ""}`}
            >
              <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                m.role === "user" ? "bg-slate-200 text-slate-800" : "bg-indigo-50 text-indigo-700 border border-indigo-100"
              }`}>
                {m.role === "user" ? <User size={15} /> : <Bot size={15} />}
              </div>

              <div className={`p-4 rounded-2xl prose max-w-none shadow-xxs ${
                m.role === "user" ? "bg-indigo-600 text-white" : "bg-slate-50 border border-slate-150"
              }`}>
                <div className="space-y-2">
                  {m.role === "user" ? (
                    <p className="text-sm leading-relaxed">{m.text}</p>
                  ) : (
                    formatText(m.text)
                  )}
                </div>
                <div className="mt-2 text-right">
                  <span className={`text-[9px] ${m.role === "user" ? "text-indigo-200" : "text-slate-400"}`}>
                    {m.timestamp}
                  </span>
                </div>
              </div>
            </div>
          ))}

          {loading && (
            <div className="flex items-start space-x-3 max-w-[80%]">
              <div className="w-8 h-8 bg-indigo-50 text-indigo-700 rounded-lg flex items-center justify-center shrink-0 border border-indigo-100">
                <Bot size={15} className="animate-spin" />
              </div>
              <div className="p-4 bg-slate-50 border border-slate-150 rounded-2xl shadow-xxs flex items-center space-x-1.5 text-xs text-slate-500 font-medium">
                <span>Gathering context portfolio & generating text draft...</span>
                <span className="dot animate-bounce">.</span>
                <span className="dot animate-bounce [animation-delay:0.2s]">.</span>
                <span className="dot animate-bounce [animation-delay:0.4s]">.</span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input box */}
        <div className="p-4.5 border-t border-slate-100 bg-slate-50 flex gap-2">
          <input 
            type="text"
            placeholder="Ask anything, draft notices, write payment reminders, summarize clauses..."
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") handleSendMessage();
            }}
            className="flex-1 text-sm bg-white border border-slate-200 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 rounded-xl px-4 py-3 outline-hidden text-slate-900 shadow-xxs"
            disabled={loading}
          />
          <button 
            onClick={() => handleSendMessage()}
            className="bg-indigo-600 hover:bg-slate-900 text-white p-3 rounded-xl shadow-xs hover:shadow-md transition-colors"
            disabled={loading}
          >
            <Send size={16} />
          </button>
        </div>

      </div>

    </div>
  );
}
