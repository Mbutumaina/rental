import React, { useState } from "react";
import { 
  CreditCard, 
  Plus, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  Filter, 
  Building2, 
  User, 
  FileCheck,
  Calendar,
  X
} from "lucide-react";
import { Payment, Tenant, Lease, Property } from "../types";

interface PaymentsProps {
  payments: Payment[];
  tenants: Tenant[];
  leases: Lease[];
  properties: Property[];
  onAddPayment: (payment: Omit<Payment, "id">) => Promise<void>;
  onUpdatePayment: (id: string, payment: Partial<Payment>) => Promise<void>;
  onSelectTab: (tab: string, contextType?: string, contextData?: any) => void;
}

export default function Payments({ 
  payments, 
  tenants, 
  leases, 
  properties, 
  onAddPayment,
  onUpdatePayment,
  onSelectTab
}: PaymentsProps) {
  
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [filterType, setFilterType] = useState<"All" | "Rent" | "Deposit" | "Late Fee" | "Utility">("All");
  const [filterStatus, setFilterStatus] = useState<"All" | "Paid" | "Pending" | "Overdue">("All");

  // Form Fields
  const [selectedTenantId, setSelectedTenantId] = useState("");
  const [amount, setAmount] = useState("");
  const [type, setType] = useState<"Rent" | "Deposit" | "Late Fee" | "Utility">("Rent");
  const [paymentStatus, setPaymentStatus] = useState<"Paid" | "Pending" | "Overdue">("Paid");
  const [date, setDate] = useState("");
  const [notes, setNotes] = useState("");

  const [loading, setLoading] = useState(false);

  // Mappings
  const tenantMap = React.useMemo(() => new Map(tenants.map(t => [t.id, t])), [tenants]);
  const propertyMap = React.useMemo(() => new Map(properties.map(p => [p.id, p])), [properties]);

  const handleOpenForm = () => {
    setSelectedTenantId("");
    setAmount("");
    setType("Rent");
    setPaymentStatus("Paid");
    setDate(new Date().toISOString().split("T")[0]);
    setNotes("");
    setIsFormOpen(true);
  };

  const handleTenantChange = (tenantId: string) => {
    setSelectedTenantId(tenantId);
    
    // Auto populate amount based on lease expectation if possible
    const tenantLease = leases.find(l => l.tenantId === tenantId && l.status === "Active");
    if (tenantLease) {
      setAmount(tenantLease.rentAmount.toString());
    } else {
      setAmount("");
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTenantId || !amount || !date) {
      alert("Please specify Resident, Payment Amount, and Timestamp.");
      return;
    }

    const linkedLease = leases.find(l => l.tenantId === selectedTenantId && l.status === "Active");
    const tenant = tenants.find(t => t.id === selectedTenantId);
    
    if (!tenant) {
      alert("Invalid resident selected.");
      return;
    }

    setLoading(true);
    const payload = {
      leaseId: linkedLease ? linkedLease.id : "no-lease",
      tenantId: selectedTenantId,
      propertyId: tenant.propertyId || "no-property",
      amount: Number(amount),
      date,
      status: paymentStatus,
      type,
      notes
    };

    try {
      await onAddPayment(payload);
      setIsFormOpen(false);
    } catch (err) {
      console.error(err);
      alert("Failed to log transaction receipts.");
    } finally {
      setLoading(false);
    }
  };

  const handleToggleStatus = async (id: string, currentStatus: "Paid" | "Pending" | "Overdue") => {
    let nextStatus: "Paid" | "Pending" | "Overdue" = "Paid";
    if (currentStatus === "Pending") {
      nextStatus = "Paid";
    } else if (currentStatus === "Paid") {
      nextStatus = "Pending";
    }
    
    try {
      await onUpdatePayment(id, { status: nextStatus });
    } catch (err) {
      console.error("Failed to alter invoice status:", err);
    }
  };

  const filteredPayments = payments.filter(p => {
    const typeMatch = filterType === "All" || p.type === filterType;
    const statusMatch = filterStatus === "All" || p.status === filterStatus;
    return typeMatch && statusMatch;
  });

  return (
    <div className="space-y-6 animate-fadeIn" id="payments-view">
      
      {/* Header element */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight flex items-center">
            <CreditCard className="mr-2.5 text-indigo-600" size={24} />
            Finance & Collections Ledger
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Reconcile rent collections, deposits, other ledger balances, and log physical check clearances.
          </p>
        </div>

        <button 
          onClick={handleOpenForm}
          className="bg-indigo-600 hover:bg-indigo-700 text-white font-medium text-sm px-4.5 py-2.5 rounded-xl inline-flex items-center shadow-xs transition-colors self-start sm:self-auto"
        >
          <Plus size={16} className="mr-1.5" />
          Log Collection Receipt
        </button>
      </div>

      {/* Filter panel */}
      <div className="flex flex-wrap gap-3 bg-white p-4.5 border border-slate-200 rounded-xl items-center justify-between" id="filter-panel">
        <div className="flex flex-wrap gap-4 items-center">
          <div className="flex items-center text-xs font-semibold text-slate-550 space-x-1.5 uppercase tracking-wider">
            <Filter size={14} className="text-indigo-500" />
            <span>Filters:</span>
          </div>
          
          {/* Rent Status Filter */}
          <div className="flex items-center space-x-1">
            <span className="text-xs text-slate-400">Invoice Status:</span>
            <select 
              value={filterStatus} 
              onChange={(e) => setFilterStatus(e.target.value as any)}
              className="text-xs bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-700 px-2.5 py-1 rounded-md outline-hidden font-medium"
            >
              <option value="All">All Invoices</option>
              <option value="Paid">Paid</option>
              <option value="Pending">Pending</option>
              <option value="Overdue">Overdue</option>
            </select>
          </div>

          {/* Money Type Filter */}
          <div className="flex items-center space-x-1">
            <span className="text-xs text-slate-400">Ledger Type:</span>
            <select 
              value={filterType} 
              onChange={(e) => setFilterType(e.target.value as any)}
              className="text-xs bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-700 px-2.5 py-1 rounded-md outline-hidden font-medium"
            >
              <option value="All">All Payments</option>
              <option value="Rent">Rent Collections</option>
              <option value="Deposit">Escrow deposits</option>
              <option value="Utility">Utilities</option>
              <option value="Late Fee">Late Fees</option>
            </select>
          </div>
        </div>

        <div className="text-xs text-slate-500 font-semibold mt-1 sm:mt-0">
          Showing {filteredPayments.length} of {payments.length} transactions
        </div>
      </div>

      {/* Table grid portal */}
      <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm">
            <thead>
              <tr className="bg-slate-55/40 border-b border-slate-200 text-xs font-bold text-slate-500 uppercase tracking-wider">
                <th className="p-4">Tenant Representative</th>
                <th className="p-4">Unit Address</th>
                <th className="p-4">Value / Amount</th>
                <th className="p-4">Paid Timestamp</th>
                <th className="p-4">Ledger Category</th>
                <th className="p-4">State</th>
                <th className="p-4 text-center">Receipt Notes</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-150 text-slate-700">
              {filteredPayments.length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center py-12 text-slate-400">
                    No matching financial transactions logged in database.
                  </td>
                </tr>
              ) : (
                filteredPayments.map(p => {
                  const tenant = tenantMap.get(p.tenantId);
                  const prop = propertyMap.get(p.propertyId);
                  
                  return (
                    <tr key={p.id} className="hover:bg-slate-50/20 transition-colors">
                      <td className="p-4">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-indigo-50 text-indigo-700 rounded-full flex items-center justify-center font-bold text-xs">
                            {tenant?.name.split(" ").map(n => n[0]).join("").slice(0, 2).toUpperCase() || "T"}
                          </div>
                          <div>
                            <span className="font-semibold text-slate-900 block">{tenant?.name || "Terminated Resident"}</span>
                            <span className="text-xxs text-slate-400">{tenant?.email}</span>
                          </div>
                        </div>
                      </td>
                      <td className="p-4">
                        <span className="text-xs text-slate-650 flex items-center max-w-xs truncate">
                          <Building2 size={12} className="mr-1 text-slate-400 shrink-0" />
                          {prop ? prop.name : "Unallocated"}
                        </span>
                      </td>
                      <td className="p-4 font-bold text-slate-950">
                        ${p.amount.toLocaleString()}
                      </td>
                      <td className="p-4 font-mono text-xs flex items-center space-x-1 py-5 text-slate-600">
                        <Calendar size={12} className="text-slate-400 mr-0.5" />
                        {p.date}
                      </td>
                      <td className="p-4">
                        <span className={`inline-flex px-2 py-0.5 rounded text-xxs font-medium ${
                          p.type === "Rent" ? "bg-indigo-50 text-indigo-700" :
                          p.type === "Deposit" ? "bg-teal-50 text-teal-700" :
                          p.type === "Late Fee" ? "bg-rose-50 text-rose-700 font-bold" :
                          "bg-amber-50 text-amber-700"
                        }`}>
                          {p.type}
                        </span>
                      </td>
                      <td className="p-4">
                        <button
                          onClick={() => handleToggleStatus(p.id, p.status)}
                          className={`inline-flex items-center px-2 py-0.5 rounded-full text-xxs font-medium border cursor-pointer hover:scale-102 active:scale-98 transition-transform ${
                            p.status === "Paid" 
                              ? "bg-emerald-50 text-emerald-800 border-emerald-100" 
                              : "bg-amber-50 text-amber-800 border-amber-100 animate-pulse"
                          }`}
                          title="Click to toggle status (Paid <-> Pending)"
                        >
                          {p.status === "Paid" ? (
                            <>
                              <CheckCircle2 size={10} className="mr-1 text-emerald-500" />
                              Paid
                            </>
                          ) : (
                            <>
                              <Clock size={10} className="mr-1 text-amber-500" />
                              Unpaid / Pend
                            </>
                          )}
                        </button>
                      </td>
                      <td className="p-4 text-xs text-slate-500 max-w-xxs truncate">
                        {p.notes || "---"}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* MODAL TRANSACTION DIALOG */}
      {isFormOpen && (
        <div className="fixed inset-0 bg-slate-950/40 backdrop-blur-xs z-50 flex justify-end animate-fadeIn" id="payment-modal">
          <div className="w-full max-w-md bg-white h-full shadow-2xl flex flex-col justify-between overflow-y-auto">
            
            <div className="p-5 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h2 className="font-bold text-slate-950 text-base">Log Physical Rent Receipt</h2>
                <p className="text-slate-400 text-xs">Verify checks, direct deposits, or utility transfers</p>
              </div>
              <button onClick={() => setIsFormOpen(false)} className="text-slate-400 hover:text-slate-650 p-1">
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-5 space-y-4 flex-1">
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">Paying Resident</label>
                <select 
                  value={selectedTenantId}
                  onChange={(e) => handleTenantChange(e.target.value)}
                  className="w-full text-sm border border-slate-200 focus:border-indigo-500 bg-white rounded-lg px-3 py-2.5 outline-hidden text-slate-900 font-semibold"
                  required
                >
                  <option value="">-- Choose Resident --</option>
                  {tenants.map(t => (
                    <option key={t.id} value={t.id}>{t.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">Collection Category</label>
                <select 
                  value={type}
                  onChange={(e) => setType(e.target.value as any)}
                  className="w-full text-sm border border-slate-200 focus:border-indigo-500 bg-white rounded-lg px-3 py-2.5 outline-hidden text-slate-900 font-semibold"
                >
                  <option value="Rent">Rent Payment</option>
                  <option value="Deposit">Security Deposit Escrow</option>
                  <option value="Late Fee">Late Fee</option>
                  <option value="Utility">Utility Sub-billing</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">Amount Paid ($)</label>
                  <input 
                    type="number"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="1800"
                    className="w-full text-sm border border-slate-200 focus:border-indigo-500 bg-white rounded-lg px-3 py-2 outline-hidden text-slate-900"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5 font-semibold">Payment Status</label>
                  <select 
                    value={paymentStatus}
                    onChange={(e) => setPaymentStatus(e.target.value as any)}
                    className="w-full text-sm border border-slate-200 focus:border-indigo-500 bg-white rounded-lg px-3 py-2 outline-hidden text-slate-900 font-medium"
                  >
                    <option value="Paid">Paid</option>
                    <option value="Pending">Pending</option>
                    <option value="Overdue">Overdue</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">Date Credited</label>
                <input 
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full text-sm border border-slate-200 bg-white rounded-lg px-3 py-2outline-hidden text-slate-900"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">Memo / Check Number</label>
                <textarea 
                  placeholder="e.g. Check #2049, June 2026 Monthly Rent"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  rows={3}
                  className="w-full text-sm border border-slate-200 bg-slate-50 focus:bg-white focus:border-indigo-500 rounded-lg p-3 outline-hidden text-slate-905 resize-none"
                />
              </div>

            </form>

            <div className="p-5 border-t border-slate-100 bg-slate-50 flex justify-end space-x-3">
              <button 
                type="button" 
                onClick={() => setIsFormOpen(false)}
                className="px-4 py-2 border border-slate-200 rounded-lg text-slate-700 text-sm font-medium hover:bg-slate-100"
              >
                Cancel
              </button>
              <button 
                onClick={handleSubmit}
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-semibold transition-colors shadow-xs"
                disabled={loading}
              >
                Log Receipt
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
