import React from "react";
import { 
  Home, 
  Users, 
  CreditCard, 
  Wrench, 
  TrendingUp, 
  Percent, 
  CheckCircle2, 
  Clock, 
  AlertCircle 
} from "lucide-react";
import { Property, Tenant, Lease, Payment, MaintenanceRequest } from "../types";

interface DashboardProps {
  properties: Property[];
  tenants: Tenant[];
  leases: Lease[];
  payments: Payment[];
  maintenance: MaintenanceRequest[];
  onSelectTab: (tab: string, contextType?: string, contextData?: any) => void;
}

export default function Dashboard({ 
  properties, 
  tenants, 
  leases, 
  payments, 
  maintenance,
  onSelectTab
}: DashboardProps) {

  // 1. Calculate Real Statistics
  const activeLeasesCount = leases.filter(l => l.status === "Active").length;
  
  const occupiedPropertiesCount = properties.filter(p => p.status === "Occupied").length;
  const occupancyRate = properties.length > 0 
    ? Math.round((occupiedPropertiesCount / properties.length) * 100) 
    : 0;

  // Monthly expected revenue (sum of active leases)
  const monthlyExpectedRevenue = leases
    .filter(l => l.status === "Active")
    .reduce((sum, l) => sum + l.rentAmount, 0);

  // Total collected payments in the last 30 days or logged in current list
  const totalCollectedPayments = payments
    .filter(p => p.status === "Paid")
    .reduce((sum, p) => sum + p.amount, 0);

  const openMaintenanceCount = maintenance.filter(m => m.status !== "Resolved" && m.status !== "Cancelled").length;
  const criticalMaintenanceCount = maintenance.filter(
    m => m.priority === "Emergency" && m.status !== "Resolved"
  ).length;

  // Recent payments
  const recentPayments = [...payments]
    .sort((a, b) => b.date.localeCompare(a.date))
    .slice(0, 4);

  // Quick lookup maps
  const propertyMap = React.useMemo(() => {
    return new Map(properties.map(p => [p.id, p]));
  }, [properties]);

  const tenantMap = React.useMemo(() => {
    return new Map(tenants.map(t => [t.id, t]));
  }, [tenants]);

  return (
    <div className="space-y-8 animate-fadeIn" id="dashboard-view">
      {/* Welcome banner */}
      <div className="bg-slate-900 text-white rounded-2xl p-6 sm:p-8 relative overflow-hidden shadow-sm">
        <div className="relative z-10 max-w-xl">
          <span className="text-xs font-semibold uppercase tracking-wider text-teal-400">Owner Portal</span>
          <h1 className="text-2xl sm:text-3xl font-semibold tracking-tight mt-1 mb-2">Welcome Back, land manager</h1>
          <p className="text-slate-300 text-sm leading-relaxed">
            Your real estate portfolio is currently operating at <span className="text-teal-400 font-semibold">{occupancyRate}% occupancy</span>. 
            There are {openMaintenanceCount} unresolved maintenance requests and {activeLeasesCount} active lease contracts.
          </p>
        </div>
        <div className="absolute top-1/2 -right-16 -translate-y-1/2 w-64 h-64 bg-teal-500/10 rounded-full blur-3xl pointer-events-none"></div>
      </div>

      {/* Grid statistics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4" id="stats-grid">
        {/* Total revenue expected */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 hover:shadow-sm transition-shadow">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">Expected Rent / Month</span>
            <div className="p-2 bg-emerald-50 rounded-lg text-emerald-600">
              <TrendingUp size={18} />
            </div>
          </div>
          <p className="text-2xl sm:text-3xl font-semibold text-slate-950 mt-2">
            ${monthlyExpectedRevenue.toLocaleString()}
          </p>
          <div className="mt-3 flex items-center text-xs text-slate-500">
            <span className="text-emerald-600 font-medium mr-1.5">Collected:</span>
             ${totalCollectedPayments.toLocaleString()} all-time
          </div>
        </div>

        {/* Occupancy Rate */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 hover:shadow-sm transition-shadow">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">Occupancy Rate</span>
            <div className="p-2 bg-indigo-50 rounded-lg text-indigo-600">
              <Percent size={18} />
            </div>
          </div>
          <div className="flex items-baseline space-x-2 mt-2">
            <p className="text-2xl sm:text-3xl font-semibold text-slate-950">{occupancyRate}%</p>
            <span className="text-xs text-slate-500">
              ({occupiedPropertiesCount}/{properties.length} units)
            </span>
          </div>
          <div className="mt-3.5 w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
            <div 
              className="bg-indigo-600 h-1.5 rounded-full transition-all duration-500" 
              style={{ width: `${occupancyRate}%` }}
            ></div>
          </div>
        </div>

        {/* Active leases */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 hover:shadow-sm transition-shadow">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">Active Leases</span>
            <div className="p-2 bg-teal-50 rounded-lg text-teal-600">
              <Users size={18} />
            </div>
          </div>
          <p className="text-2xl sm:text-3xl font-semibold text-slate-950 mt-2">{activeLeasesCount}</p>
          <div className="mt-3 flex items-center text-xs text-slate-500">
            <span className="text-teal-600 font-medium mr-1">Active agreements</span> linked to tenants
          </div>
        </div>

        {/* Open Maintenance requests */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 hover:shadow-sm transition-shadow">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">Maintenance Requests</span>
            <div className="p-2 bg-rose-50 rounded-lg text-rose-600">
              <Wrench size={18} />
            </div>
          </div>
          <p className="text-2xl sm:text-3xl font-semibold text-slate-950 mt-2">{openMaintenanceCount}</p>
          <div className="mt-3 flex items-center text-xs text-slate-500">
            {criticalMaintenanceCount > 0 ? (
              <span className="text-rose-600 font-medium bg-rose-50 px-1.5 py-0.5 rounded flex items-center">
                <AlertCircle size={12} className="mr-1 animate-pulse" /> {criticalMaintenanceCount} Urgent Ticket(s)
              </span>
            ) : (
              <span className="text-slate-600">All calm, no emergency items</span>
            )}
          </div>
        </div>
      </div>

      {/* Main split sections */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="dashboard-splits">
        {/* Left side: interactive occupancy list & quick start actions */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-white border border-slate-200 rounded-xl p-6">
            <h3 className="font-semibold text-slate-900 mb-4">Properties Portfolio Overview</h3>
            <div className="space-y-3">
              {properties.slice(0, 3).map(p => (
                <div key={p.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-100 hover:border-slate-200 transition-colors">
                  <div className="flex items-center space-x-3">
                    <img 
                      src={p.imageUrl} 
                      alt={p.name} 
                      className="w-12 h-12 rounded bg-cover bg-center object-cover"
                      referrerPolicy="no-referrer"
                    />
                    <div>
                      <h4 className="font-medium text-slate-950 text-sm">{p.name}</h4>
                      <p className="text-xs text-slate-500 mt-0.5">{p.address}</p>
                    </div>
                  </div>
                  <div className="flex flex-col items-end">
                    <span className="text-sm font-semibold text-slate-900">${p.rentAmount}/mo</span>
                    <span className={`inline-flex items-center px-2 py-0.5 mt-1 rounded-full text-xxs font-medium ${
                      p.status === "Occupied" ? "bg-teal-50 text-teal-700 border border-teal-100" :
                      p.status === "Maintenance" ? "bg-rose-50 text-rose-700 border border-rose-100" :
                      "bg-amber-50 text-amber-700 border border-amber-100"
                    }`}>
                      {p.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="mt-4 pt-4 border-t border-slate-100 text-center">
              <button 
                onClick={() => onSelectTab("properties")}
                className="text-indigo-600 hover:text-indigo-700 text-sm font-medium hover:underline inline-flex items-center"
              >
                Manage all properties portfolio →
              </button>
            </div>
          </div>

          {/* Quick AI Task Suggestions */}
          <div className="bg-gradient-to-tr from-indigo-50 to-teal-50 border border-indigo-100 rounded-xl p-6">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-semibold text-indigo-950 text-sm flex items-center">
                <span className="w-2 h-2 rounded-full bg-indigo-500 mr-2 animate-pulse"></span>
                Suggestive AI Assistant Actions
              </h3>
              <span className="text-[10px] bg-indigo-200/50 text-indigo-800 px-2 py-0.5 rounded-full font-semibold uppercase">Powered by Gemini</span>
            </div>
            <p className="text-slate-600 text-xs mb-4">
              Our intelligent engine can draft, compute, and synthesize records on demand. Click any to open the Assistant desk:
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <button 
                onClick={() => onSelectTab("ai", "Property", properties[0])}
                className="text-left bg-white/70 hover:bg-white border border-indigo-100 p-3 rounded-lg text-xs font-medium text-indigo-900 transition-colors hover:shadow-xs"
              >
                ✏️ Draft Welcome Pack for Cedar Meadow
              </button>
              <button 
                onClick={() => onSelectTab("ai", "Tenant", tenants[0])}
                className="text-left bg-white/70 hover:bg-white border border-indigo-100 p-3 rounded-lg text-xs font-medium text-indigo-900 transition-colors hover:shadow-xs"
              >
                📧 Write friendly Rent Reminder
              </button>
              <button 
                onClick={() => onSelectTab("ai", "Maintenance", maintenance[0])}
                className="text-left bg-white/70 hover:bg-white border border-indigo-100 p-3 rounded-lg text-xs font-medium text-indigo-900 transition-colors hover:shadow-xs"
              >
                🛠️ Draft plumber notice for garbage disposal
              </button>
              <button 
                onClick={() => onSelectTab("ai")}
                className="text-left bg-white/70 hover:bg-white border border-indigo-100 p-3 rounded-lg text-xs font-medium text-indigo-900 transition-colors hover:shadow-xs"
              >
                💼 Generate a generic commercial lease terms template
              </button>
            </div>
          </div>
        </div>

        {/* Right side: rent status log */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white border border-slate-200 rounded-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-slate-900">Recent Rent Receipts</h3>
              <button 
                onClick={() => onSelectTab("payments")}
                className="text-indigo-600 hover:text-indigo-700 text-xs font-medium hover:underline"
              >
                View all logs
              </button>
            </div>

            <div className="divide-y divide-slate-100">
              {recentPayments.length === 0 ? (
                <div className="text-center py-6 text-slate-400 text-sm">No payment records logged yet.</div>
              ) : (
                recentPayments.map(p => {
                  const propertyName = propertyMap.get(p.propertyId)?.name || "Unknown Property";
                  const tenantName = tenantMap.get(p.tenantId)?.name || "Unknown Tenant";
                  return (
                    <div key={p.id} className="py-3 flex justify-between items-center first:pt-0 last:pb-0">
                      <div>
                        <h4 className="font-medium text-slate-900 text-sm">{tenantName}</h4>
                        <p className="text-xs text-slate-500 mt-0.5">{propertyName}</p>
                        <p className="text-xxs text-slate-400 mt-0.5">{p.date}</p>
                      </div>
                      <div className="text-right">
                        <span className="font-semibold text-slate-900">${p.amount}</span>
                        <div className="mt-1">
                          <span className={`inline-flex items-center px-1.5 py-0.5 rounded text-xxs font-medium ${
                            p.status === "Paid" ? "bg-emerald-50 text-emerald-700" :
                            p.status === "Overdue" ? "bg-rose-50 text-rose-700" :
                            "bg-slate-50 text-slate-600"
                          }`}>
                            {p.status === "Paid" && <CheckCircle2 size={10} className="mr-0.5" />}
                            {p.status === "Pending" && <Clock size={10} className="mr-0.5 text-slate-400 animate-pulse" />}
                            {p.status === "Overdue" && <AlertCircle size={10} className="mr-0.5" />}
                            {p.status}
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Maintenance quick checklist */}
          <div className="bg-white border border-slate-200 rounded-xl p-6">
            <h3 className="font-semibold text-slate-900 mb-4">Outstanding Tickets</h3>
            <div className="space-y-3">
              {maintenance.filter(m => m.status !== "Resolved").slice(0, 3).map(m => {
                const prop = propertyMap.get(m.propertyId);
                return (
                  <div key={m.id} className="p-3 bg-red-50/20 border border-slate-100 rounded-lg">
                    <div className="flex items-start justify-between">
                      <div>
                        <span className={`inline-flex px-1.5 py-0.5 rounded text-xxs font-semibold tracking-wider ${
                          m.priority === "Emergency" ? "bg-red-100 text-red-800" :
                          m.priority === "High" ? "bg-amber-100 text-amber-800" :
                          "bg-slate-100 text-slate-700"
                        }`}>
                          {m.priority}
                        </span>
                        <h4 className="font-semibold text-slate-950 text-xs mt-1.5">{m.title}</h4>
                        <p className="text-xxs text-slate-500 mt-1">{prop?.name || "Multiple Properties"}</p>
                      </div>
                      <span className="text-xxs font-medium text-slate-500">
                        {m.status}
                      </span>
                    </div>
                  </div>
                );
              })}
              {maintenance.filter(m => m.status !== "Resolved").length === 0 && (
                <div className="text-center py-6 text-slate-400 text-sm">
                  ✨ No active maintenance tickets to address!
                </div>
              )}
            </div>
            
            <div className="mt-4 pt-4 border-t border-slate-100 text-center">
              <button 
                onClick={() => onSelectTab("maintenance")}
                className="text-indigo-600 hover:text-indigo-700 text-sm font-medium hover:underline inline-flex items-center"
              >
                Go to Maintenance Service Desk →
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
