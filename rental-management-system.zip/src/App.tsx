import React, { useState, useEffect } from "react";
import { 
  Building2, 
  Users, 
  CreditCard, 
  Wrench, 
  Sparkles, 
  LayoutDashboard,
  Home,
  Menu,
  X,
  FileCheck,
  ShieldCheck,
  RefreshCw
} from "lucide-react";
import { apiFetch } from "./utils";
import { Property, Tenant, Lease, Payment, MaintenanceRequest } from "./types";

// Component imports
import Dashboard from "./components/Dashboard";
import Properties from "./components/Properties";
import Tenants from "./components/Tenants";
import Payments from "./components/Payments";
import Maintenance from "./components/Maintenance";
import AIAssistant from "./components/AIAssistant";

export default function App() {
  const [activeTab, setActiveTab] = useState<string>("dashboard");
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Core Data Lists
  const [properties, setProperties] = useState<Property[]>([]);
  const [tenants, setTenants] = useState<Tenant[]>([]);
  const [leases, setLeases] = useState<Lease[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [maintenance, setMaintenance] = useState<MaintenanceRequest[]>([]);

  // AI Context Passing
  const [aiContextType, setAiContextType] = useState<string | undefined>(undefined);
  const [aiContextData, setAiContextData] = useState<any | undefined>(undefined);

  // Network State
  const [refreshing, setRefreshing] = useState(false);
  const [networkError, setNetworkError] = useState<string | null>(null);

  // Core Data Loader
  const loadAllData = async () => {
    setRefreshing(true);
    setNetworkError(null);
    try {
      const [propsRes, tenantsRes, leasesRes, paymentsRes, maintRes] = await Promise.all([
        apiFetch<Property[]>("/api/properties"),
        apiFetch<Tenant[]>("/api/tenants"),
        apiFetch<Lease[]>("/api/leases"),
        apiFetch<Payment[]>("/api/payments"),
        apiFetch<MaintenanceRequest[]>("/api/maintenance")
      ]);

      setProperties(propsRes);
      setTenants(tenantsRes);
      setLeases(leasesRes);
      setPayments(paymentsRes);
      setMaintenance(maintRes);
    } catch (err: any) {
      console.error("Failed to sync backend lists:", err);
      setNetworkError("Failed to synchronizing active credentials with cloud container database.");
    } finally {
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadAllData();
  }, []);

  // ----------------------------------------------------
  // Sync Handlers (CRUD operations linking REST)
  // ----------------------------------------------------

  // Properties API
  const handleAddProperty = async (newProp: Omit<Property, "id" | "createdAt">) => {
    try {
      await apiFetch<Property>("/api/properties", {
        method: "POST",
        body: JSON.stringify(newProp)
      });
      await loadAllData();
    } catch (err) {
      console.error(err);
      throw err;
    }
  };

  const handleUpdateProperty = async (id: string, updatedFields: Partial<Property>) => {
    try {
      await apiFetch<Property>(`/api/properties/${id}`, {
        method: "PUT",
        body: JSON.stringify(updatedFields)
      });
      await loadAllData();
    } catch (err) {
      console.error(err);
      throw err;
    }
  };

  const handleDeleteProperty = async (id: string) => {
    try {
      await apiFetch<{ success: boolean }>(`/api/properties/${id}`, {
        method: "DELETE"
      });
      await loadAllData();
    } catch (err) {
      console.error(err);
      throw err;
    }
  };

  // Tenants API
  const handleAddTenant = async (newTenant: Omit<Tenant, "id" | "createdAt">) => {
    try {
      await apiFetch<Tenant>("/api/tenants", {
        method: "POST",
        body: JSON.stringify(newTenant)
      });
      await loadAllData();
    } catch (err) {
      console.error(err);
      throw err;
    }
  };

  const handleUpdateTenant = async (id: string, updatedFields: Partial<Tenant>) => {
    try {
      await apiFetch<Tenant>(`/api/tenants/${id}`, {
        method: "PUT",
        body: JSON.stringify(updatedFields)
      });
      await loadAllData();
    } catch (err) {
      console.error(err);
      throw err;
    }
  };

  const handleDeleteTenant = async (id: string) => {
    try {
      await apiFetch<{ success: boolean }>(`/api/tenants/${id}`, {
        method: "DELETE"
      });
      await loadAllData();
    } catch (err) {
      console.error(err);
      throw err;
    }
  };

  // Leases API
  const handleCreateLease = async (newLease: Omit<Lease, "id" | "createdAt">) => {
    try {
      await apiFetch<Lease>("/api/leases", {
        method: "POST",
        body: JSON.stringify(newLease)
      });
      await loadAllData();
    } catch (err) {
      console.error(err);
      throw err;
    }
  };

  const handleUpdateLease = async (id: string, updatedFields: Partial<Lease>) => {
    try {
      await apiFetch<Lease>(`/api/leases/${id}`, {
        method: "PUT",
        body: JSON.stringify(updatedFields)
      });
      await loadAllData();
    } catch (err) {
      console.error(err);
      throw err;
    }
  };

  const handleDeleteLease = async (id: string) => {
    try {
      await apiFetch<{ success: boolean }>(`/api/leases/${id}`, {
        method: "DELETE"
      });
      await loadAllData();
    } catch (err) {
      console.error(err);
      throw err;
    }
  };

  // Payments API
  const handleAddPayment = async (newPayment: Omit<Payment, "id">) => {
    try {
      await apiFetch<Payment>("/api/payments", {
        method: "POST",
        body: JSON.stringify(newPayment)
      });
      await loadAllData();
    } catch (err) {
      console.error(err);
      throw err;
    }
  };

  const handleUpdatePayment = async (id: string, updatedFields: Partial<Payment>) => {
    try {
      await apiFetch<Payment>(`/api/payments/${id}`, {
        method: "PUT",
        body: JSON.stringify(updatedFields)
      });
      await loadAllData();
    } catch (err) {
      console.error(err);
      throw err;
    }
  };

  // Maintenance API
  const handleAddMaintenance = async (newMaint: Omit<MaintenanceRequest, "id" | "dateReported" | "dateResolved">) => {
    try {
      await apiFetch<MaintenanceRequest>("/api/maintenance", {
        method: "POST",
        body: JSON.stringify(newMaint)
      });
      await loadAllData();
    } catch (err) {
      console.error(err);
      throw err;
    }
  };

  const handleUpdateMaintenance = async (id: string, updatedFields: Partial<MaintenanceRequest>) => {
    try {
      await apiFetch<MaintenanceRequest>(`/api/maintenance/${id}`, {
        method: "PUT",
        body: JSON.stringify(updatedFields)
      });
      await loadAllData();
    } catch (err) {
      console.error(err);
      throw err;
    }
  };

  // Helper to jump screens and set context
  const handleSelectTabWithContext = (tabName: string, contextType?: string, contextData?: any) => {
    if (contextType && contextData) {
      setAiContextType(contextType);
      setAiContextData(contextData);
    }
    setActiveTab(tabName);
    setIsMobileMenuOpen(false);
  };

  // ----------------------------------------------------
  // Render views routing
  // ----------------------------------------------------
  const renderActiveView = () => {
    switch (activeTab) {
      case "dashboard":
        return (
          <Dashboard 
            properties={properties} 
            tenants={tenants} 
            leases={leases} 
            payments={payments} 
            maintenance={maintenance}
            onSelectTab={handleSelectTabWithContext}
          />
        );
      case "properties":
        return (
          <Properties 
            properties={properties} 
            onAddProperty={handleAddProperty}
            onUpdateProperty={handleUpdateProperty}
            onDeleteProperty={handleDeleteProperty}
            onSelectTab={handleSelectTabWithContext}
          />
        );
      case "tenants":
        return (
          <Tenants 
            tenants={tenants}
            properties={properties}
            leases={leases}
            onAddTenant={handleAddTenant}
            onUpdateTenant={handleUpdateTenant}
            onDeleteTenant={handleDeleteTenant}
            onCreateLease={handleCreateLease}
            onUpdateLease={handleUpdateLease}
            onDeleteLease={handleDeleteLease}
            onSelectTab={handleSelectTabWithContext}
          />
        );
      case "payments":
        return (
          <Payments 
            payments={payments} 
            tenants={tenants}
            leases={leases}
            properties={properties}
            onAddPayment={handleAddPayment}
            onUpdatePayment={handleUpdatePayment}
            onSelectTab={handleSelectTabWithContext}
          />
        );
      case "maintenance":
        return (
          <Maintenance 
            maintenance={maintenance} 
            tenants={tenants}
            properties={properties}
            onAddMaintenance={handleAddMaintenance}
            onUpdateMaintenance={handleUpdateMaintenance}
            onSelectTab={handleSelectTabWithContext}
          />
        );
      case "ai":
        return (
          <AIAssistant 
            initialContextType={aiContextType}
            initialContextData={aiContextData}
            onClearContext={() => {
              setAiContextType(undefined);
              setAiContextData(undefined);
            }}
          />
        );
      default:
        return <div className="text-center py-10">Select an option from sidebar.</div>;
    }
  };

  return (
    <div className="min-h-screen bg-[#fcfcfd] text-slate-800 flex flex-col font-sans" id="applet-container">
      
      {/* Top Banner alert if database disconnects */}
      {networkError && (
        <div className="bg-rose-50 border-b border-rose-200 text-rose-800 text-xs px-4 py-3 flex items-center justify-between font-medium">
          <div className="flex items-center space-x-2">
            <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse"></span>
            <span>{networkError}</span>
          </div>
          <button 
            onClick={loadAllData} 
            className="text-rose-900 underline hover:no-underline font-semibold text-xxs tracking-wider uppercase"
          >
            Reconnect local db
          </button>
        </div>
      )}

      {/* Main Structural Layout */}
      <div className="flex flex-1 flex-col md:flex-row">
        
        {/* SIDEBAR NAVIGATION (Desktop) */}
        <aside className="w-full md:w-64 bg-slate-950 text-white shrink-0 hidden md:flex flex-col justify-between border-r border-slate-900" id="sidebar-desktop">
          <div className="p-6">
            {/* Logo */}
            <div className="flex items-center space-x-3 mb-8">
              <div className="w-8 h-8 rounded-lg bg-indigo-550 flex items-center justify-center font-bold text-white bg-indigo-600 shadow-sm shadow-indigo-500/20">
                <Home size={16} />
              </div>
              <div>
                <span className="font-bold text-sm tracking-tight block">Rently Ledger</span>
                <span className="text-[10px] text-slate-400 font-medium">Rental Management</span>
              </div>
            </div>

            {/* Nav list */}
            <nav className="space-y-1.5">
              <button 
                onClick={() => handleSelectTabWithContext("dashboard")}
                className={`w-full flex items-center space-x-3 text-xs font-semibold px-4.5 py-3.5 rounded-xl transition-all ${
                  activeTab === "dashboard" 
                    ? "bg-slate-900 text-white shadow-inner" 
                    : "text-slate-400 hover:text-white hover:bg-slate-900/50"
                }`}
              >
                <LayoutDashboard size={14} />
                <span>Dashboard</span>
              </button>

              <button 
                onClick={() => handleSelectTabWithContext("properties")}
                className={`w-full flex items-center space-x-3 text-xs font-semibold px-4.5 py-3.5 rounded-xl transition-all ${
                  activeTab === "properties" 
                    ? "bg-slate-900 text-white shadow-inner" 
                    : "text-slate-400 hover:text-white hover:bg-slate-900/50"
                }`}
              >
                <Building2 size={14} />
                <span>Properties</span>
              </button>

              <button 
                onClick={() => handleSelectTabWithContext("tenants")}
                className={`w-full flex items-center space-x-3 text-xs font-semibold px-4.5 py-3.5 rounded-xl transition-all ${
                  activeTab === "tenants" 
                    ? "bg-slate-900 text-white shadow-inner" 
                    : "text-slate-400 hover:text-white hover:bg-slate-900/50"
                }`}
              >
                <Users size={14} />
                <span>Residents & Leases</span>
              </button>

              <button 
                onClick={() => handleSelectTabWithContext("payments")}
                className={`w-full flex items-center space-x-3 text-xs font-semibold px-4.5 py-3.5 rounded-xl transition-all ${
                  activeTab === "payments" 
                    ? "bg-slate-900 text-white shadow-inner" 
                    : "text-slate-400 hover:text-white hover:bg-slate-900/50"
                }`}
              >
                <CreditCard size={14} />
                <span>Ledger & Rent</span>
              </button>

              <button 
                onClick={() => handleSelectTabWithContext("maintenance")}
                className={`w-full flex items-center space-x-3 text-xs font-semibold px-4.5 py-3.5 rounded-xl transition-all ${
                  activeTab === "maintenance" 
                    ? "bg-slate-900 text-white shadow-inner" 
                    : "text-slate-400 hover:text-white hover:bg-slate-900/50"
                }`}
              >
                <Wrench size={14} />
                <span>Service Tickets</span>
              </button>

              <button 
                onClick={() => handleSelectTabWithContext("ai")}
                className={`w-full flex items-center space-x-3 text-xs font-semibold px-4.5 py-3.5 rounded-xl transition-all ${
                  activeTab === "ai" 
                    ? "bg-gradient-to-r from-indigo-900 to-indigo-850 text-white shadow-inner" 
                    : "text-slate-405 text-slate-400 hover:text-white hover:bg-indigo-950/20"
                }`}
              >
                <Sparkles size={14} className="text-teal-400" />
                <span className="flex-1 text-left">Gemini AI Liaison</span>
                <span className="bg-teal-500/20 text-teal-400 text-3xs font-bold leading-none px-1.5 py-0.5 rounded-full uppercase scale-90">Auto</span>
              </button>
            </nav>
          </div>

          {/* System Footer status */}
          <div className="p-6 border-t border-slate-900 space-y-3.5">
            <div className="flex items-center justify-between text-3xs text-slate-500 font-semibold uppercase tracking-wider">
              <span>Database state:</span>
              <span className="text-teal-400 font-bold">Online</span>
            </div>
            
            <button 
              onClick={loadAllData}
              disabled={refreshing}
              className="w-full flex items-center justify-center space-x-1.5 text-3xs text-slate-400 hover:text-white bg-slate-900 border border-slate-800 rounded-lg p-2.5 hover:bg-slate-850 active:scale-98 transition-all"
            >
              <RefreshCw size={10} className={refreshing ? "animate-spin" : ""} />
              <span>{refreshing ? "Synching..." : "Force DB Synchronize"}</span>
            </button>
          </div>
        </aside>

        {/* MOBILE MENU NAV & TOP BAR */}
        <header className="bg-slate-950 text-white md:hidden py-4 px-5 flex items-center justify-between border-b border-slate-900" id="mobile-topbar">
          <div className="flex items-center space-x-2.5">
            <div className="w-7 h-7 rounded-md bg-indigo-600 flex items-center justify-center font-bold">
              <Home size={14} />
            </div>
            <span className="font-bold text-sm tracking-tight text-white">Rently Portal</span>
          </div>

          <button 
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="text-slate-400 hover:text-white p-1"
          >
            {isMobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </header>

        {/* Mobile menu sheet overlay */}
        {isMobileMenuOpen && (
          <div className="bg-slate-950 text-white border-b border-slate-900 p-5 space-y-3 md:hidden animate-fadeIn" id="mobile-menu-overlay">
            <nav className="grid grid-cols-2 gap-2">
              <button 
                onClick={() => handleSelectTabWithContext("dashboard")}
                className={`p-3 rounded-lg text-xs font-semibold text-center ${activeTab === 'dashboard' ? 'bg-indigo-600 text-white' : 'bg-slate-900 text-slate-400'}`}
              >
                Dashboard
              </button>
              <button 
                onClick={() => handleSelectTabWithContext("properties")}
                className={`p-3 rounded-lg text-xs font-semibold text-center ${activeTab === 'properties' ? 'bg-indigo-600 text-white' : 'bg-slate-900 text-slate-400'}`}
              >
                Properties
              </button>
              <button 
                onClick={() => handleSelectTabWithContext("tenants")}
                className={`p-3 rounded-lg text-xs font-semibold text-center ${activeTab === 'tenants' ? 'bg-indigo-600 text-white' : 'bg-slate-900 text-slate-400'}`}
              >
                Residents
              </button>
              <button 
                onClick={() => handleSelectTabWithContext("payments")}
                className={`p-3 rounded-lg text-xs font-semibold text-center ${activeTab === 'payments' ? 'bg-indigo-600 text-white' : 'bg-slate-900 text-slate-400'}`}
              >
                Ledger
              </button>
              <button 
                onClick={() => handleSelectTabWithContext("maintenance")}
                className={`p-3 rounded-lg text-xs font-semibold text-center ${activeTab === 'maintenance' ? 'bg-indigo-600 text-white' : 'bg-slate-900 text-slate-400'}`}
              >
                Maintenance
              </button>
              <button 
                onClick={() => handleSelectTabWithContext("ai")}
                className={`p-3 rounded-lg text-xs font-semibold text-center col-span-2 ${activeTab === 'ai' ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white' : 'bg-slate-900 text-slate-400'}`}
              >
                ✨ Gemini AI Assistant
              </button>
            </nav>
          </div>
        )}

        {/* WORKSPACE APP VIEWS CONTAINER */}
        <main className="flex-1 p-6 sm:p-10 max-w-7xl mx-auto w-full overflow-x-hidden">
          {renderActiveView()}
        </main>

      </div>
    </div>
  );
}
